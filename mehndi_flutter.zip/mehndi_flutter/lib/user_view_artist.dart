// user_view_artist_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mehndi_flutter/user_chat.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

import 'gallery.dart';

class UserViewArtistPage extends StatefulWidget {
  const UserViewArtistPage({super.key});

  @override
  State<UserViewArtistPage> createState() => _UserViewArtistPageState();
}

class _UserViewArtistPageState extends State<UserViewArtistPage> {
  List<Artist> _artists = [];
  List<Artist> _filteredArtists = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';
  String _searchQuery = '';
  String _selectedSpecialization = 'All';
  List<String> _specializations = ['All'];

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  // Controllers
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchArtists();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  // Fetch all artists
  Future<void> _fetchArtists() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_all_artists/'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _artists = (data['artists'] as List)
                .map((json) => Artist.fromJson(json))
                .toList();
            _filteredArtists = _artists;
            _extractSpecializations();
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load artists');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Extract unique specializations
  void _extractSpecializations() {
    Set<String> specializations = {};
    for (var artist in _artists) {
      if (artist.specialization.isNotEmpty) {
        specializations.add(artist.specialization);
      }
    }
    _specializations = ['All', ...specializations.toList()..sort()];
  }

  // Filter artists based on search and specialization
  void _filterArtists() {
    setState(() {
      _filteredArtists = _artists.where((artist) {
        bool matchesSearch = _searchQuery.isEmpty ||
            artist.fullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            artist.specialization.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            artist.city.toLowerCase().contains(_searchQuery.toLowerCase());

        bool matchesSpecialization = _selectedSpecialization == 'All' ||
            artist.specialization == _selectedSpecialization;

        return matchesSearch && matchesSpecialization;
      }).toList();
    });
  }

  // Navigate to chat
  void _navigateToChat(Artist artist) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatPage(artistId: artist.id.toString(), artistName: artist.fullName),
      ),
    );
  }

  // Navigate to gallery
  void _navigateToGallery(Artist artist) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ViewGalleryPage(artistId: artist.id, artistName: artist.fullName),
      ),
    );
  }

  // Open Send Request Bottom Sheet
  void _openSendRequestSheet(Artist artist) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SendRequestSheet(
        artistId: artist.id,
        artistName: artist.fullName,
        baseUrl: _baseUrl,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildSearchAndFilterSection(),
          Expanded(
            child: _filteredArtists.isEmpty
                ? _buildEmptyWidget()
                : _buildArtistsList(),
          ),
        ],
      ),
    );
  }

  // App Bar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text(
        'Mehandi Artists',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchArtists,
        ),
      ],
    );
  }

  // Loading Indicator with Lottie
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/animations/henna_loading.json',
            width: 150,
            height: 150,
          ),
          const SizedBox(height: 20),
          Text(
            'Finding artists for you...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error Widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Search and Filter Section
  Widget _buildSearchAndFilterSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by name, specialization, or city...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _filterArtists();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _filterArtists();
                });
              },
            ),
          ),
          const SizedBox(height: 12),

          // Specialization Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _specializations.map((spec) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(spec),
                    selected: _selectedSpecialization == spec,
                    onSelected: (selected) {
                      setState(() {
                        _selectedSpecialization = spec;
                        _filterArtists();
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: hennaGold,
                    checkmarkColor: hennaDeep,
                    labelStyle: TextStyle(
                      color: _selectedSpecialization == spec
                          ? hennaDeep
                          : hennaBrown,
                      fontWeight: _selectedSpecialization == spec
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: _selectedSpecialization == spec
                            ? hennaDeep
                            : hennaGold.withOpacity(0.3),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  // Empty Widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/animations/henna_empty.json',
            width: 200,
            height: 200,
          ),
          const SizedBox(height: 20),
          Text(
            'No Artists Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty
                ? 'No artists match your search criteria'
                : 'Check back later for new artists',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Artists List
  Widget _buildArtistsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredArtists.length,
      itemBuilder: (context, index) {
        final artist = _filteredArtists[index];
        return _buildArtistCard(artist);
      },
    );
  }

  // Artist Card
  Widget _buildArtistCard(Artist artist) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
          side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
        ),
        color: hennaCream,
        child: Column(
          children: [
            // Artist Header with Image and Basic Info
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Artist Image
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: hennaGold, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: hennaBrown.withOpacity(0.2),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: artist.profileImage != null
                          ? Image.network(
                        _getFullImageUrl(artist.profileImage),
                        fit: BoxFit.cover,
                        width: 80,
                        height: 80,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Center(
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                            ),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: hennaLight,
                            child: Icon(Icons.person, size: 40, color: hennaGold),
                          );
                        },
                      )
                          : Container(
                        color: hennaLight,
                        child: Icon(Icons.person, size: 40, color: hennaGold),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),

                  // Artist Details
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          artist.fullName,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Iconsax.brush_1, size: 14, color: hennaGold),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                artist.specialization,
                                style: TextStyle(
                                  fontSize: 13,
                                  color: hennaBrown,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Iconsax.location, size: 14, color: hennaGold),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                '${artist.city} - ${artist.pincode}',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Iconsax.star1, size: 14, color: hennaGold),
                            const SizedBox(width: 4),
                            Text(
                              '${artist.experienceYears} years experience',
                              style: TextStyle(
                                fontSize: 12,
                                color: hennaBrown.withOpacity(0.7),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Action Buttons
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: hennaLight,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(25),
                  bottomRight: Radius.circular(25),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Chat Button
                  _buildActionButton(
                    icon: Iconsax.message,
                    label: 'Chat',
                    color: hennaSage,
                    onTap: () => _navigateToChat(artist),
                  ),

                  // Vertical Divider
                  Container(
                    height: 30,
                    width: 1,
                    color: hennaGold.withOpacity(0.3),
                  ),

                  // View Gallery Button
                  _buildActionButton(
                    icon: Iconsax.gallery,
                    label: 'Gallery',
                    color: hennaRose,
                    onTap: () => _navigateToGallery(artist),
                  ),

                  // Vertical Divider
                  Container(
                    height: 30,
                    width: 1,
                    color: hennaGold.withOpacity(0.3),
                  ),

                  // Send Request Button
                  _buildActionButton(
                    icon: Iconsax.send_1,
                    label: 'Request',
                    color: hennaBrown,
                    onTap: () => _openSendRequestSheet(artist),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Action Button Helper
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: hennaDeep,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Artist Model Class
class Artist {
  final int id;
  final String fname;
  final String lname;
  final String phone;
  final String? profileImage;
  final int experienceYears;
  final String specialization;
  final String bio;
  final String address;
  final String city;
  final String pincode;

  Artist({
    required this.id,
    required this.fname,
    required this.lname,
    required this.phone,
    this.profileImage,
    required this.experienceYears,
    required this.specialization,
    required this.bio,
    required this.address,
    required this.city,
    required this.pincode,
  });

  factory Artist.fromJson(Map<String, dynamic> json) {
    return Artist(
      id: json['id'] ?? 0,
      fname: json['fname'] ?? '',
      lname: json['lname'] ?? '',
      phone: json['phone'] ?? '',
      profileImage: json['profile_image'],
      experienceYears: int.tryParse(json['experience_years'].toString()) ?? 0,
      specialization: json['specialization'] ?? '',
      bio: json['bio'] ?? '',
      address: json['address'] ?? '',
      city: json['city'] ?? '',
      pincode: json['pincode'] ?? '',
    );
  }

  String get fullName => '$fname $lname';
}

// Send Request Bottom Sheet (Scrollable)
class SendRequestSheet extends StatefulWidget {
  final int artistId;
  final String artistName;
  final String baseUrl;

  const SendRequestSheet({
    super.key,
    required this.artistId,
    required this.artistName,
    required this.baseUrl,
  });

  @override
  State<SendRequestSheet> createState() => _SendRequestSheetState();
}

class _SendRequestSheetState extends State<SendRequestSheet> {
  final _formKey = GlobalKey<FormState>();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  bool _isSubmitting = false;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: hennaBrown,
              onPrimary: Colors.white,
              surface: hennaCream,
              onSurface: hennaDeep,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: hennaBrown,
              onPrimary: Colors.white,
              surface: hennaCream,
              onSurface: hennaDeep,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _submitRequest() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedDate == null) {
      _showSnackBar('Please select a booking date', hennaGold);
      return;
    }
    if (_selectedTime == null) {
      _showSnackBar('Please select a booking time', hennaGold);
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('lid');

      if (userId == null) {
        _showSnackBar('User not logged in', Colors.red);
        return;
      }

      // Format date and time
      String formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDate!);
      String formattedTime = _selectedTime!.format(context);

      final response = await http.post(
        Uri.parse('${widget.baseUrl}/myapp/send_booking_request/'),
        body: {
          'artist_id': widget.artistId.toString(),
          'user_id': userId,
          'booking_date': formattedDate,
          'booking_time': formattedTime,
          'status': 'pending',
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        Navigator.pop(context);
        _showSuccessDialog();
      } else {
        throw Exception(data['message'] ?? 'Failed to send request');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    } finally {
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              color == Colors.green ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          backgroundColor: hennaCream,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaBrown, hennaGold],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                  ),
                  child: const Icon(
                    Iconsax.tick_circle,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Request Sent!',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: hennaDeep,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Your booking request has been sent to ${widget.artistName}',
                  style: const TextStyle(color: hennaBrown),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(3, (index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      child: Icon(
                        Icons.circle,
                        color: hennaGold.withOpacity(0.3),
                        size: 6,
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: hennaBrown,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text('OK'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.calendar_1, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'Book Appointment',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Artist name
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: hennaGold.withOpacity(0.3)),
                ),
                child: Text(
                  'Booking with ${widget.artistName}',
                  style: TextStyle(
                    fontSize: 14,
                    color: hennaDeep,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Form - Now Scrollable
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        // Date Picker
                        GestureDetector(
                          onTap: _selectDate,
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: hennaLight,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: hennaGold.withOpacity(0.5)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: hennaBrown.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(Iconsax.calendar, color: hennaBrown),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Booking Date',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: hennaBrown.withOpacity(0.7),
                                        ),
                                      ),
                                      Text(
                                        _selectedDate == null
                                            ? 'Select date'
                                            : DateFormat('EEEE, MMMM dd, yyyy').format(_selectedDate!),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: _selectedDate == null ? hennaBrown.withOpacity(0.5) : hennaDeep,
                                          fontWeight: _selectedDate == null ? FontWeight.normal : FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(Iconsax.arrow_right_3, color: hennaBrown),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Time Picker
                        GestureDetector(
                          onTap: _selectTime,
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: hennaLight,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: hennaGold.withOpacity(0.5)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: hennaBrown.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(Iconsax.clock, color: hennaBrown),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Booking Time',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: hennaBrown.withOpacity(0.7),
                                        ),
                                      ),
                                      Text(
                                        _selectedTime == null
                                            ? 'Select time'
                                            : _selectedTime!.format(context),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: _selectedTime == null ? hennaBrown.withOpacity(0.5) : hennaDeep,
                                          fontWeight: _selectedTime == null ? FontWeight.normal : FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(Iconsax.arrow_right_3, color: hennaBrown),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Status note
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: hennaGold.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: hennaGold.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(Iconsax.info_circle, color: hennaBrown, size: 18),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Your request will be sent to the artist for approval. You will be notified once confirmed.',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: hennaDeep,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Submit button
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => Navigator.pop(context),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: hennaBrown,
                                  side: BorderSide(color: hennaBrown),
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: const Text('Cancel'),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [hennaBrown, hennaDeep],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: ElevatedButton(
                                  onPressed: _isSubmitting ? null : _submitRequest,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent,
                                    foregroundColor: Colors.white,
                                    shadowColor: Colors.transparent,
                                    padding: const EdgeInsets.symmetric(vertical: 15),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                  child: _isSubmitting
                                      ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(hennaGold),
                                    ),
                                  )
                                      : const Text('Send Request'),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20), // Extra bottom padding
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}