// view_artist_bookings_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';

// Artist Booking Model Class
class ArtistBooking {
  final int id;
  final DateTime bookingDate;
  final String bookingTime;
  final String status;
  final DateTime createdAt;
  final int artistId;
  final int userId;
  final String userFname;
  final String userLname;
  final String userPhone;
  final String? userProfileImage;
  final double amount;
  final FeedbackData? feedback;

  ArtistBooking({
    required this.id,
    required this.bookingDate,
    required this.bookingTime,
    required this.status,
    required this.createdAt,
    required this.artistId,
    required this.userId,
    required this.userFname,
    required this.userLname,
    required this.userPhone,
    this.userProfileImage,
    required this.amount,
    this.feedback,
  });

  factory ArtistBooking.fromJson(Map<String, dynamic> json) {
    return ArtistBooking(
      id: json['id'] ?? 0,
      bookingDate: DateTime.tryParse(json['booking_date'] ?? '') ?? DateTime.now(),
      bookingTime: json['booking_time'] ?? '',
      status: json['status'] ?? 'pending',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      artistId: json['artist_id'] ?? 0,
      userId: json['user_id'] ?? 0,
      userFname: json['user_fname'] ?? '',
      userLname: json['user_lname'] ?? '',
      userPhone: json['user_phone'] ?? '',
      userProfileImage: json['user_profile_image'],
      amount: double.tryParse(json['amount'].toString()) ?? 0.0,
      feedback: json['feedback'] != null ? FeedbackData.fromJson(json['feedback']) : null,
    );
  }

  String get userFullName => '$userFname $userLname';

  Color get statusColor {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      case 'completed':
        return Colors.blue;
      case 'paid':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  IconData get statusIcon {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Iconsax.tick_circle;
      case 'pending':
        return Iconsax.clock;
      case 'cancelled':
        return Iconsax.close_circle;
      case 'completed':
        return Iconsax.tick_circle;
      case 'paid':
        return Iconsax.wallet_3;
      default:
        return Iconsax.info_circle;
    }
  }

  Color get statusBackgroundColor {
    return statusColor.withOpacity(0.1);
  }

  String get formattedBookingDate {
    return DateFormat('EEEE, MMMM dd, yyyy').format(bookingDate);
  }

  String get formattedCreatedDate {
    return DateFormat('MMM dd, yyyy • hh:mm a').format(createdAt);
  }

  bool get isUpcoming {
    final now = DateTime.now();
    final bookingDateTime = DateTime(
      bookingDate.year,
      bookingDate.month,
      bookingDate.day,
      int.parse(bookingTime.split(':')[0]),
      int.parse(bookingTime.split(':')[1]),
    );
    return bookingDateTime.isAfter(now) && status.toLowerCase() == 'confirmed';
  }

  bool get isPaymentPending {
    return status.toLowerCase() == 'pending' && amount > 0;
  }

  bool get canGiveFeedback {
    return (status.toLowerCase() == 'paid' || status.toLowerCase() == 'completed') && feedback == null;
  }
}

// Feedback Model Class
class FeedbackData {
  final int id;
  final double rating;
  final String comment;
  final DateTime createdAt;
  final int bookingId;

  FeedbackData({
    required this.id,
    required this.rating,
    required this.comment,
    required this.createdAt,
    required this.bookingId,
  });

  factory FeedbackData.fromJson(Map<String, dynamic> json) {
    return FeedbackData(
      id: json['id'] ?? 0,
      rating: double.tryParse(json['rating'].toString()) ?? 0.0,
      comment: json['comment'] ?? '',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      bookingId: json['booking_id'] ?? 0,
    );
  }

  String get formattedDate {
    return DateFormat('MMM dd, yyyy').format(createdAt);
  }

  List<Widget> get starIcons {
    List<Widget> stars = [];
    int fullStars = rating.floor();
    bool hasHalfStar = (rating - fullStars) >= 0.5;

    for (int i = 0; i < fullStars; i++) {
      stars.add(const Icon(Iconsax.star1, color: Colors.amber, size: 16));
    }
    if (hasHalfStar) {
      stars.add(const Icon(Iconsax.star, color: Colors.amber, size: 16));
    }
    for (int i = stars.length; i < 5; i++) {
      stars.add(Icon(Iconsax.star, color: Colors.grey.shade300, size: 16));
    }
    return stars;
  }
}

class ViewArtistBookingsPage extends StatefulWidget {
  const ViewArtistBookingsPage({super.key});

  @override
  State<ViewArtistBookingsPage> createState() => _ViewArtistBookingsPageState();
}

class _ViewArtistBookingsPageState extends State<ViewArtistBookingsPage> {
  List<ArtistBooking> _bookings = [];
  List<ArtistBooking> _filteredBookings = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';

  // Razorpay
  late Razorpay _razorpay;
  bool _isProcessing = false;
  int? _currentPaymentBookingId;

  // Filter options
  String _selectedFilter = 'All';
  final List<String> _filterOptions = ['All', 'Pending', 'Confirmed', 'Completed', 'Cancelled', 'Paid'];

  // Date filter
  DateTime? _selectedDate;

  // Search controller
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Stats
  int _pendingCount = 0;
  int _confirmedCount = 0;
  int _completedCount = 0;
  int _cancelledCount = 0;
  int _upcomingCount = 0;
  int _paidCount = 0;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _initRazorpay();
    _loadBaseUrl();
  }

  void _initRazorpay() {
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    _searchController.dispose();
    super.dispose();
  }

  // Razorpay Payment Handlers
  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    setState(() {
      _isProcessing = false;
    });

    print("Payment Success Response: ${response.paymentId}");
    print("Payment Success Data: ${response.data}");

    Fluttertoast.showToast(
      msg: "Payment Successful! 🎉",
      backgroundColor: Colors.green,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
      timeInSecForIosWeb: 2,
    );

    if (_currentPaymentBookingId != null) {
      _updatePaymentStatus(_currentPaymentBookingId!, response.paymentId);
    } else {
      _fetchArtistBookings();
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    setState(() {
      _isProcessing = false;
    });

    Fluttertoast.showToast(
      msg: "Payment Failed: ${response.message ?? 'Unknown error'}",
      backgroundColor: Colors.red,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    setState(() {
      _isProcessing = false;
    });

    Fluttertoast.showToast(
      msg: "External Wallet: ${response.walletName}",
      backgroundColor: hennaBrown,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
    );
  }

  void _openCheckout(ArtistBooking booking) {
    setState(() {
      _isProcessing = true;
      _currentPaymentBookingId = booking.id;
    });

    print("Opening checkout for booking: ${booking.id}, Amount: ${booking.amount}");

    var options = {
      'key': 'rzp_test_HKCAwYtLt0rwQe',
      'amount': (booking.amount * 100).round(),
      'name': 'Mehandi Art Studio',
      'description': 'Payment for Booking #${booking.id}',
      'prefill': {
        'contact': booking.userPhone,
        'name': booking.userFullName,
      },
      'notes': {
        'booking_id': booking.id.toString(),
        'user_id': booking.userId.toString(),
        'artist_id': booking.artistId.toString(),
      },
      'theme': {
        'color': '#8B4C39'
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print("Error opening Razorpay: $e");
      setState(() {
        _isProcessing = false;
        _currentPaymentBookingId = null;
      });

      Fluttertoast.showToast(
        msg: "Payment initialization failed",
        backgroundColor: Colors.red,
        textColor: Colors.white,
        gravity: ToastGravity.TOP,
      );
    }
  }

  Future<void> _updatePaymentStatus(int bookingId, String? paymentId) async {
    print("Updating payment status for booking $bookingId with payment ID $paymentId");

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/payment_success/'),
        body: {
          'booking_id': bookingId.toString(),
          'payment_id': paymentId ?? '',
        },
      );

      print("Response status code: ${response.statusCode}");
      print("Response body: ${response.body}");

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == 'success') {
          Fluttertoast.showToast(
            msg: "Payment status updated!",
            backgroundColor: Colors.green,
            textColor: Colors.white,
            gravity: ToastGravity.TOP,
          );

          await _fetchArtistBookings();

          // Show feedback option after payment
          _showFeedbackOption(bookingId);
        } else {
          throw Exception(data['message'] ?? 'Failed to update payment status');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      print("Error updating payment status: $e");
      Fluttertoast.showToast(
        msg: "Error updating payment status",
        backgroundColor: Colors.red,
        textColor: Colors.white,
        gravity: ToastGravity.TOP,
      );
    } finally {
      setState(() {
        _currentPaymentBookingId = null;
      });
    }
  }

  // Show feedback option after payment
  void _showFeedbackOption(int bookingId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Thank You!'),
        content: const Text('Would you like to share your feedback about this booking?'),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Later', style: TextStyle(color: hennaBrown)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showFeedbackDialog(bookingId);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: hennaBrown,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Give Feedback'),
          ),
        ],
      ),
    );
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchArtistBookings();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  // Fetch artist bookings
  Future<void> _fetchArtistBookings() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('lid');

      if (userId == null) {
        setState(() {
          _errorMessage = 'Artist not logged in';
          _isLoading = false;
        });
        return;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_artist_bookings/'),
        body: {'lid': userId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _bookings = (data['bookings'] as List)
                .map((json) => ArtistBooking.fromJson(json))
                .toList();

            // Debug print to check feedback data
            print("========== FEEDBACK DEBUG ==========");
            for (var booking in _bookings) {
              print("Booking ID: ${booking.id}");
              print("  Has Feedback: ${booking.feedback != null}");
              if (booking.feedback != null) {
                print("  Rating: ${booking.feedback!.rating}");
                print("  Comment: ${booking.feedback!.comment}");
                print("  Date: ${booking.feedback!.formattedDate}");
              }
            }
            print("====================================");

            _calculateStats();
            _applyFilters();
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load bookings');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Calculate statistics
  void _calculateStats() {
    _pendingCount = _bookings.where((b) => b.status.toLowerCase() == 'pending').length;
    _confirmedCount = _bookings.where((b) => b.status.toLowerCase() == 'confirmed').length;
    _completedCount = _bookings.where((b) => b.status.toLowerCase() == 'completed').length;
    _cancelledCount = _bookings.where((b) => b.status.toLowerCase() == 'cancelled').length;
    _upcomingCount = _bookings.where((b) => b.isUpcoming).length;
    _paidCount = _bookings.where((b) => b.status.toLowerCase() == 'paid').length;
  }

  // Apply filters
  void _applyFilters() {
    List<ArtistBooking> filtered = List.from(_bookings);

    if (_selectedFilter != 'All') {
      filtered = filtered.where((booking) =>
      booking.status.toLowerCase() == _selectedFilter.toLowerCase()
      ).toList();
    }

    if (_selectedDate != null) {
      filtered = filtered.where((booking) {
        return booking.bookingDate.year == _selectedDate!.year &&
            booking.bookingDate.month == _selectedDate!.month &&
            booking.bookingDate.day == _selectedDate!.day;
      }).toList();
    }

    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((booking) =>
      booking.userFullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          booking.userPhone.contains(_searchQuery) ||
          booking.id.toString().contains(_searchQuery)
      ).toList();
    }

    filtered.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    setState(() {
      _filteredBookings = filtered;
    });
  }

  // Clear all filters
  void _clearFilters() {
    setState(() {
      _selectedFilter = 'All';
      _selectedDate = null;
      _searchController.clear();
      _searchQuery = '';
      _applyFilters();
    });
  }

  // Select date
  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: hennaBrown,
              onPrimary: Colors.white,
              surface: hennaCream,
              onSurface: hennaDeep,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _applyFilters();
      });
    }
  }

  // Update booking status
  Future<void> _updateBookingStatus(int bookingId, String newStatus) async {
    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/update_booking_status/'),
        body: {
          'booking_id': bookingId.toString(),
          'status': newStatus,
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('Booking ${newStatus.toLowerCase()} successfully', Colors.green);
        await _fetchArtistBookings();
      } else {
        throw Exception(data['message'] ?? 'Failed to update status');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Show booking details
  void _showBookingDetails(ArtistBooking booking) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildBookingDetailsSheet(booking),
    );
  }

  // Show status update dialog
  void _showStatusUpdateDialog(ArtistBooking booking) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update Booking Status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.green.withOpacity(0.1),
                child: const Icon(Iconsax.tick_circle, color: Colors.green),
              ),
              title: const Text('Confirm Booking'),
              onTap: () {
                Navigator.pop(context);
                _updateBookingStatus(booking.id, 'confirmed');
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue.withOpacity(0.1),
                child: const Icon(Iconsax.tick_circle, color: Colors.blue),
              ),
              title: const Text('Mark as Completed'),
              onTap: () {
                Navigator.pop(context);
                _updateBookingStatus(booking.id, 'completed');
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.purple.withOpacity(0.1),
                child: const Icon(Iconsax.wallet_3, color: Colors.purple),
              ),
              title: const Text('Mark as Paid'),
              onTap: () {
                Navigator.pop(context);
                _updateBookingStatus(booking.id, 'paid');
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.red.withOpacity(0.1),
                child: const Icon(Iconsax.close_circle, color: Colors.red),
              ),
              title: const Text('Cancel Booking'),
              onTap: () {
                Navigator.pop(context);
                _updateBookingStatus(booking.id, 'cancelled');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
      ),
    );
  }

  // Show feedback dialog
  void _showFeedbackDialog(int bookingId) {
    double rating = 0;
    TextEditingController commentController = TextEditingController();
    bool isSubmitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => Container(
          height: MediaQuery.of(context).size.height * 0.6,
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.message, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    'Share Feedback',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Text(
                        'How was your experience?',
                        style: TextStyle(
                          fontSize: 16,
                          color: hennaDeep,
                        ),
                      ),
                      const SizedBox(height: 20),
                      // Rating Stars
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(5, (index) {
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                rating = index + 1.0;
                              });
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: Icon(
                                index < rating ? Iconsax.star1 : Iconsax.star,
                                size: 40,
                                color: index < rating ? Colors.amber : Colors.grey.shade300,
                              ),
                            ),
                          );
                        }),
                      ),
                      const SizedBox(height: 20),
                      if (rating > 0)
                        Text(
                          _getRatingText(rating),
                          style: TextStyle(
                            color: hennaBrown,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      const SizedBox(height: 20),
                      // Comment Field
                      Container(
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: TextField(
                          controller: commentController,
                          maxLines: 4,
                          decoration: InputDecoration(
                            hintText: 'Share your experience...',
                            hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.all(16),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      // Submit Button
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: hennaBrown,
                                side: BorderSide(color: hennaBrown),
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: const Text('Cancel'),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [hennaBrown, hennaDeep],
                                ),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: ElevatedButton(
                                onPressed: isSubmitting
                                    ? null
                                    : () async {
                                  if (rating == 0) {
                                    Fluttertoast.showToast(
                                      msg: "Please select a rating",
                                      backgroundColor: Colors.orange,
                                      textColor: Colors.white,
                                    );
                                    return;
                                  }
                                  setState(() => isSubmitting = true);
                                  await _submitFeedback(
                                    bookingId,
                                    rating,
                                    commentController.text,
                                  );
                                  Navigator.pop(context);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  foregroundColor: Colors.white,
                                  shadowColor: Colors.transparent,
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: isSubmitting
                                    ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                  ),
                                )
                                    : const Text('Submit'),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Show feedback view dialog
  void _showFeedbackViewDialog(FeedbackData feedback) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        backgroundColor: hennaCream,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: hennaBrown.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(Iconsax.star1, color: hennaGold, size: 30),
              ),
              const SizedBox(height: 16),
              const Text(
                'Customer Feedback',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: hennaDeep,
                ),
              ),
              const SizedBox(height: 16),
              // Rating Stars
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: feedback.starIcons,
              ),
              const SizedBox(height: 12),
              Text(
                '${feedback.rating.toStringAsFixed(1)} / 5.0',
                style: TextStyle(
                  color: hennaBrown,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              // Comment
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: hennaGold.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Comment:',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: hennaDeep,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      feedback.comment,
                      style: TextStyle(
                        fontSize: 14,
                        color: hennaBrown,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Submitted on ${feedback.formattedDate}',
                style: TextStyle(
                  fontSize: 12,
                  color: hennaBrown.withOpacity(0.7),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: hennaBrown,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: const Text('Close'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Submit feedback to server
  Future<void> _submitFeedback(int bookingId, double rating, String comment) async {
    try {
      // Convert rating to integer (floor it to remove decimal)
      int intRating = rating.floor();

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/submit_feedback/'),
        body: {
          'booking_id': bookingId.toString(),
          'rating': intRating.toString(), // Send as integer
          'comment': comment,
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        Fluttertoast.showToast(
          msg: "Thank you for your feedback!",
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
        await _fetchArtistBookings();
      } else {
        throw Exception(data['message'] ?? 'Failed to submit feedback');
      }
    } catch (e) {
      print("Error submitting feedback: $e");
      Fluttertoast.showToast(
        msg: "Error submitting feedback",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }
  }

  String _getRatingText(double rating) {
    if (rating >= 4.5) return "Excellent! 🌟";
    if (rating >= 4.0) return "Very Good! 👍";
    if (rating >= 3.0) return "Good! 👌";
    if (rating >= 2.0) return "Average 🤔";
    return "Needs Improvement 📝";
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(color == Colors.green ? Icons.check_circle : Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildStatsSection(),
          _buildFilterBar(),
          Expanded(
            child: _filteredBookings.isEmpty
                ? _buildEmptyWidget()
                : _buildBookingsList(),
          ),
        ],
      ),
    );
  }

  // App Bar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text(
        'Artist Bookings',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchArtistBookings,
        ),
      ],
    );
  }

  // Stats Section
  Widget _buildStatsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Overview',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildStatCard(
                  label: 'Pending',
                  count: _pendingCount,
                  color: Colors.orange,
                  icon: Iconsax.clock,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Confirmed',
                  count: _confirmedCount,
                  color: Colors.green,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Completed',
                  count: _completedCount,
                  color: Colors.blue,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Paid',
                  count: _paidCount,
                  color: Colors.purple,
                  icon: Iconsax.wallet_3,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Upcoming',
                  count: _upcomingCount,
                  color: hennaBrown,
                  icon: Iconsax.calendar_1,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Cancelled',
                  count: _cancelledCount,
                  color: Colors.red,
                  icon: Iconsax.close_circle,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Stat Card
  Widget _buildStatCard({
    required String label,
    required int count,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 4),
              Text(
                count.toString(),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  // Filter Bar
  Widget _buildFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by customer name or phone...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _applyFilters();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _applyFilters();
                });
              },
            ),
          ),
          const SizedBox(height: 12),

          // Filter Chips Row
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ..._filterOptions.map((filter) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(filter),
                      selected: _selectedFilter == filter,
                      onSelected: (selected) {
                        setState(() {
                          _selectedFilter = filter;
                          _applyFilters();
                        });
                      },
                      backgroundColor: Colors.white,
                      selectedColor: hennaGold,
                      checkmarkColor: hennaDeep,
                      labelStyle: TextStyle(
                        color: _selectedFilter == filter ? hennaDeep : hennaBrown,
                        fontWeight: _selectedFilter == filter ? FontWeight.bold : FontWeight.normal,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: _selectedFilter == filter ? hennaDeep : hennaGold.withOpacity(0.3),
                        ),
                      ),
                    ),
                  );
                }),
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(
                    label: Text(
                      _selectedDate == null
                          ? 'Select Date'
                          : DateFormat('dd MMM yyyy').format(_selectedDate!),
                    ),
                    onPressed: _selectDate,
                    backgroundColor: _selectedDate != null ? hennaGold : Colors.white,
                    labelStyle: TextStyle(
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    avatar: Icon(
                      Iconsax.calendar,
                      size: 16,
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: hennaGold.withOpacity(0.3)),
                    ),
                  ),
                ),
                if (_selectedFilter != 'All' || _selectedDate != null || _searchQuery.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: const Text('Clear'),
                      onPressed: _clearFilters,
                      backgroundColor: hennaLight,
                      labelStyle: TextStyle(color: hennaBrown),
                      avatar: Icon(Iconsax.close_circle, size: 16, color: hennaBrown),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(color: hennaGold.withOpacity(0.3)),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredBookings.length} bookings found',
                  style: TextStyle(
                    color: hennaBrown,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Loading Indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading your bookings...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error Widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Empty Widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: hennaGold.withOpacity(0.1),
            ),
            child: Icon(
              Iconsax.calendar,
              size: 60,
              color: hennaGold,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'No Bookings Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null
                ? 'No bookings match your filters'
                : 'You have no booking requests yet',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          if (_searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null)
            ElevatedButton(
              onPressed: _clearFilters,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Clear Filters'),
            ),
        ],
      ),
    );
  }

  // Bookings List
  Widget _buildBookingsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredBookings.length,
      itemBuilder: (context, index) {
        final booking = _filteredBookings[index];
        return _buildBookingCard(booking);
      },
    );
  }

  // Booking Card
  Widget _buildBookingCard(ArtistBooking booking) {
    return GestureDetector(
      onTap: () => _showBookingDetails(booking),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
          ),
          color: hennaCream,
          child: Column(
            children: [
              // User Info Row
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    // User Profile Image
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: hennaGold, width: 2),
                      ),
                      child: ClipOval(
                        child: booking.userProfileImage != null
                            ? Image.network(
                          _getFullImageUrl(booking.userProfileImage),
                          fit: BoxFit.cover,
                          width: 60,
                          height: 60,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: hennaLight,
                              child: Icon(Icons.person, size: 30, color: hennaGold),
                            );
                          },
                        )
                            : Container(
                          color: hennaLight,
                          child: Icon(Icons.person, size: 30, color: hennaGold),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),

                    // User Details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            booking.userFullName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.call, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                booking.userPhone,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.calendar, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                DateFormat('dd MMM yyyy').format(booking.bookingDate),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Icon(Iconsax.clock, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                booking.bookingTime,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                          if (booking.amount > 0) ...[
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(Iconsax.money, size: 12, color: hennaGold),
                                const SizedBox(width: 4),
                                Text(
                                  'Amount: ₹${booking.amount.toStringAsFixed(2)}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: booking.isPaymentPending ? Colors.orange : Colors.green,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Status Bar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Status Badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: booking.statusBackgroundColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: booking.statusColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            booking.statusIcon,
                            size: 14,
                            color: booking.statusColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            booking.status.toUpperCase(),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: booking.statusColor,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Action Buttons
                    Row(
                      children: [
                        // Feedback Button (if feedback exists)
                        if (booking.feedback != null)
                          InkWell(
                            onTap: () => _showFeedbackViewDialog(booking.feedback!),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.amber.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Iconsax.star1,
                                color: Colors.amber,
                                size: 18,
                              ),
                            ),
                          ),

                        // Give Feedback Button (if can give feedback)
                        if (booking.canGiveFeedback)
                          InkWell(
                            onTap: () => _showFeedbackDialog(booking.id),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: hennaBrown.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Iconsax.message,
                                color: hennaBrown,
                                size: 18,
                              ),
                            ),
                          ),

                        if (booking.feedback != null || booking.canGiveFeedback)
                          const SizedBox(width: 8),

                        // Payment Button for pending payments
                        if (booking.isPaymentPending)
                          InkWell(
                            onTap: _isProcessing ? null : () => _openCheckout(booking),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.orange.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: _isProcessing
                                  ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
                                ),
                              )
                                  : const Icon(
                                Iconsax.wallet_3,
                                color: Colors.orange,
                                size: 18,
                              ),
                            ),
                          ),
                        if (booking.isPaymentPending) const SizedBox(width: 8),

                        // Status update buttons for pending bookings
                        if (booking.status.toLowerCase() == 'pending' && !booking.isPaymentPending)
                          Row(
                            children: [
                              InkWell(
                                onTap: () => _updateBookingStatus(booking.id, 'confirmed'),
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.green.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Iconsax.tick_circle,
                                    color: Colors.green,
                                    size: 18,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              InkWell(
                                onTap: () => _updateBookingStatus(booking.id, 'cancelled'),
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.red.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Iconsax.close_circle,
                                    color: Colors.red,
                                    size: 18,
                                  ),
                                ),
                              ),
                            ],
                          ),

                        // Complete button for confirmed bookings
                        if (booking.status.toLowerCase() == 'confirmed')
                          InkWell(
                            onTap: () => _updateBookingStatus(booking.id, 'completed'),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Iconsax.tick_circle,
                                color: Colors.blue,
                                size: 18,
                              ),
                            ),
                          ),

                        const SizedBox(width: 8),

                        // More options button

                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Booking Details Bottom Sheet
  Widget _buildBookingDetailsSheet(ArtistBooking booking) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.calendar_1, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'Booking Details',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),

              // Scrollable Content
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Customer Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Artist Information',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaDeep,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Container(
                                  width: 70,
                                  height: 70,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: hennaGold, width: 2),
                                  ),
                                  child: ClipOval(
                                    child: booking.userProfileImage != null
                                        ? Image.network(
                                      _getFullImageUrl(booking.userProfileImage),
                                      fit: BoxFit.cover,
                                      width: 70,
                                      height: 70,
                                      loadingBuilder: (context, child, loadingProgress) {
                                        if (loadingProgress == null) return child;
                                        return Center(
                                          child: CircularProgressIndicator(
                                            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                                          ),
                                        );
                                      },
                                      errorBuilder: (context, error, stackTrace) {
                                        return Container(
                                          color: hennaLight,
                                          child: Icon(Icons.person, size: 35, color: hennaGold),
                                        );
                                      },
                                    )
                                        : Container(
                                      color: hennaLight,
                                      child: Icon(Icons.person, size: 35, color: hennaGold),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        booking.userFullName,
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: hennaDeep,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      _buildDetailRow(Iconsax.call, booking.userPhone),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Booking Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Booking Information',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaDeep,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildDetailRow(Iconsax.calendar, 'Booking Date: ${booking.formattedBookingDate}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.clock, 'Booking Time: ${booking.bookingTime}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.receipt, 'Booking ID: #${booking.id}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.calendar_1, 'Requested on: ${booking.formattedCreatedDate}'),
                            if (booking.amount > 0) ...[
                              const SizedBox(height: 8),
                              _buildDetailRow(
                                Iconsax.money,
                                'Amount: ₹${booking.amount.toStringAsFixed(2)}',
                                isAmount: true,
                                amountColor: booking.isPaymentPending ? Colors.orange : Colors.green,
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Feedback Card (if exists)
                      if (booking.feedback != null) ...[
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.amber.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.amber.withOpacity(0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Iconsax.star1, color: Colors.amber, size: 20),
                                  const SizedBox(width: 8),
                                  const Text(
                                    'Customer Feedback',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: hennaDeep,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: booking.feedback!.starIcons,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Rating: ${booking.feedback!.rating.toStringAsFixed(1)} / 5.0',
                                style: TextStyle(
                                  color: hennaBrown,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: hennaLight,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  booking.feedback!.comment,
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: hennaDeep,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Submitted on ${booking.feedback!.formattedDate}',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // Status Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: booking.statusBackgroundColor,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: booking.statusColor.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: booking.statusColor.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                booking.statusIcon,
                                color: booking.statusColor,
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Current Status',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: hennaDeep,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    booking.status.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: booking.statusColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Action Buttons
                      if (booking.isPaymentPending)
                        Column(
                          children: [
                            Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Colors.orange, Colors.deepOrange],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                ),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: ElevatedButton(
                                onPressed: _isProcessing ? null : () => _openCheckout(booking),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  foregroundColor: Colors.white,
                                  shadowColor: Colors.transparent,
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: _isProcessing
                                    ? const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    ),
                                    SizedBox(width: 12),
                                    Text('Processing...'),
                                  ],
                                )
                                    : const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Iconsax.wallet_3, size: 20),
                                    SizedBox(width: 12),
                                    Text(
                                      'Pay Now',
                                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                        ),

                      if (booking.canGiveFeedback)
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [hennaBrown, hennaGold],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              _showFeedbackDialog(booking.id);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.white,
                              shadowColor: Colors.transparent,
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Iconsax.message, size: 20),
                                SizedBox(width: 12),
                                Text(
                                  'Give Feedback',
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),

                      if (booking.status.toLowerCase() == 'pending' && !booking.isPaymentPending)
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => Navigator.pop(context),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: hennaBrown,
                                  side: const BorderSide(color: hennaBrown),
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: const Text('Close'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Colors.green, Colors.greenAccent],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    _updateBookingStatus(booking.id, 'confirmed');
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent,
                                    foregroundColor: Colors.white,
                                    shadowColor: Colors.transparent,
                                    padding: const EdgeInsets.symmetric(vertical: 15),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                  child: const Text('Confirm Booking'),
                                ),
                              ),
                            ),
                          ],
                        )
                      else if (booking.status.toLowerCase() == 'confirmed')
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => Navigator.pop(context),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: hennaBrown,
                                  side: const BorderSide(color: hennaBrown),
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: const Text('Close'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Colors.blue, Colors.lightBlueAccent],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    _updateBookingStatus(booking.id, 'completed');
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent,
                                    foregroundColor: Colors.white,
                                    shadowColor: Colors.transparent,
                                    padding: const EdgeInsets.symmetric(vertical: 15),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                  child: const Text('Mark Completed'),
                                ),
                              ),
                            ),
                          ],
                        )
                      else
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => Navigator.pop(context),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: hennaBrown,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            child: const Text('Close'),
                          ),
                        ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Detail Row Helper
  Widget _buildDetailRow(IconData icon, String text, {bool isAmount = false, Color? amountColor}) {
    return Row(
      children: [
        Icon(icon, size: 16, color: hennaGold),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              color: isAmount ? amountColor : hennaDeep,
              fontWeight: isAmount ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }
}