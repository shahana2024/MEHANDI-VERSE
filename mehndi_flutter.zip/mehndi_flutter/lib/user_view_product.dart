// view_products_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mehndi_flutter/user_home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
// Order Bottom Sheet
// Add these imports at the top of your file
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
// Product Model Class
class Product {
  final int id;
  final String art_name;
  final String name;
  final String description;
  final double price;
  final int stock;
  final String? imageUrl;
  final String isApproved;
  final DateTime createdAt;
  final int artistId;

  Product({
    required this.art_name,
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.stock,
    this.imageUrl,
    required this.isApproved,
    required this.createdAt,
    required this.artistId,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      art_name: json['arti_name'] ?? '',
      description: json['description'] ?? '',
      price: double.tryParse(json['price'].toString()) ?? 0.0,
      stock: int.tryParse(json['stock'].toString()) ?? 0,
      imageUrl: json['image_url'],
      isApproved: json['is_approved'] ?? 'pending',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      artistId: json['artist_id'] ?? 0,
    );
  }
}

class ViewProductsPage extends StatefulWidget {
  const ViewProductsPage({super.key});

  @override
  State<ViewProductsPage> createState() => _ViewProductsPageState();
}

class _ViewProductsPageState extends State<ViewProductsPage> {
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';
  String _searchQuery = '';

  // Filter options
  String _selectedSort = 'All';
  final List<String> _sortOptions = ['All', 'Low to High', 'High to Low', 'In Stock'];

  // Controllers
  final TextEditingController _searchController = TextEditingController();

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchProducts();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  // Fetch all products
  Future<void> _fetchProducts() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/user_view_products/'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _products = (data['products'] as List)
                .map((json) => Product.fromJson(json))
                .where((product) => product.isApproved == 'Accept') // Show only approved products
                .toList();
            _filteredProducts = _products;
            _applyFilters();
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load products');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Apply filters and sorting
  void _applyFilters() {
    List<Product> filtered = List.from(_products);

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((product) =>
      product.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          product.description.toLowerCase().contains(_searchQuery.toLowerCase())
      ).toList();
    }

    // Apply sorting
    switch (_selectedSort) {
      case 'Low to High':
        filtered.sort((a, b) => a.price.compareTo(b.price));
        break;
      case 'High to Low':
        filtered.sort((a, b) => b.price.compareTo(a.price));
        break;
      case 'In Stock':
        filtered = filtered.where((product) => product.stock > 0).toList();
        filtered.sort((a, b) => b.stock.compareTo(a.stock));
        break;
      default:
      // Keep original order or sort by newest first
        filtered.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }

    setState(() {
      _filteredProducts = filtered;
    });
  }

  // Open order bottom sheet
  void _openOrderSheet(Product product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => OrderSheet(product: product, baseUrl: _baseUrl),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildSearchAndFilterBar(),
          Expanded(
            child: _filteredProducts.isEmpty
                ? _buildEmptyWidget()
                : _buildProductsList(),
          ),
        ],
      ),
    );
  }

  // App Bar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text(
        'Mehandi Products',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchProducts,
        ),
      ],
    );
  }

  // Loading Indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading products...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error Widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Search and Filter Bar
  Widget _buildSearchAndFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search products...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _applyFilters();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _applyFilters();
                });
              },
            ),
          ),
          const SizedBox(height: 12),

          // Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _sortOptions.map((option) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(option),
                    selected: _selectedSort == option,
                    onSelected: (selected) {
                      setState(() {
                        _selectedSort = option;
                        _applyFilters();
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: hennaGold,
                    checkmarkColor: hennaDeep,
                    labelStyle: TextStyle(
                      color: _selectedSort == option ? hennaDeep : hennaBrown,
                      fontWeight: _selectedSort == option ? FontWeight.bold : FontWeight.normal,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: _selectedSort == option ? hennaDeep : hennaGold.withOpacity(0.3),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          // Result count
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredProducts.length} products found',
                  style: TextStyle(
                    color: hennaBrown,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Empty Widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.shopping_bag_outlined, size: 100, color: hennaGold),
          const SizedBox(height: 20),
          Text(
            'No Products Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty
                ? 'No products match your search'
                : 'Check back later for new products',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Products List
  Widget _buildProductsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredProducts.length,
      itemBuilder: (context, index) {
        final product = _filteredProducts[index];
        return _buildProductCard(product);
      },
    );
  }

  // Product Card
  Widget _buildProductCard(Product product) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
        ),
        color: hennaCream,
        child: Column(
          children: [
            // Product Image and Details Row
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Product Image
                ClipRRect(
                  borderRadius: const BorderRadius.horizontal(
                    left: Radius.circular(18),
                  ),
                  child: Container(
                    width: 120,
                    height: 120,
                    color: hennaLight,
                    child: product.imageUrl != null
                        ? Image.network(
                      _getFullImageUrl(product.imageUrl),
                      fit: BoxFit.cover,
                      width: 120,
                      height: 120,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return Center(
                          child: Icon(Icons.image, size: 40, color: hennaGold),
                        );
                      },
                    )
                        : Center(
                      child: Icon(Icons.image, size: 40, color: hennaGold),
                    ),
                  ),
                ),

                // Product Details
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Product Name
                        Text(
                          product.name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4), Text(
                          "Product By ${product.art_name}",

                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),

                        // Price
                        Row(
                          children: [
                            Icon(Iconsax.money, size: 14, color: hennaGold),
                            const SizedBox(width: 4),
                            Text(
                              '₹${product.price.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaBrown,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),

                        // Stock Status
                        Row(
                          children: [
                            Icon(
                              product.stock > 0 ? Iconsax.tick_circle : Iconsax.close_circle,
                              size: 14,
                              color: product.stock > 0 ? Colors.green : Colors.red,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              product.stock > 0 ? 'In Stock: ${product.stock}' : 'Out of Stock',
                              style: TextStyle(
                                fontSize: 12,
                                color: product.stock > 0 ? Colors.green : Colors.red,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),

                        // Order Button
                        if (product.stock > 0)
                          Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [hennaBrown, hennaDeep],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: ElevatedButton(
                              onPressed: () => _openOrderSheet(product),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                foregroundColor: Colors.white,
                                shadowColor: Colors.transparent,
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Iconsax.shopping_cart, size: 16),
                                  SizedBox(width: 8),
                                  Text('Order Now'),
                                ],
                              ),
                            ),
                          )
                        else
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: const Center(
                              child: Text(
                                'Out of Stock',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Description
            if (product.description.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Iconsax.note, size: 14, color: hennaGold),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        product.description,
                        style: TextStyle(
                          fontSize: 12,
                          color: hennaBrown.withOpacity(0.8),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}



// Updated OrderSheet class with Razorpay integration
class OrderSheet extends StatefulWidget {
  final Product product;
  final String baseUrl;

  const OrderSheet({
    super.key,
    required this.product,
    required this.baseUrl,
  });

  @override
  State<OrderSheet> createState() => _OrderSheetState();
}

class _OrderSheetState extends State<OrderSheet> {
  int _quantity = 1;
  double _totalPrice = 0;
  bool _isSubmitting = false;

  // Razorpay integration
  late Razorpay _razorpay;
  bool _isProcessing = false;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);

  @override
  void initState() {
    super.initState();
    _updateTotalPrice();

    // Initialize Razorpay
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear(); // Clean up Razorpay
    super.dispose();
  }

  void _updateTotalPrice() {
    setState(() {
      _totalPrice = widget.product.price * _quantity;
    });
  }

  void _incrementQuantity() {
    if (_quantity < widget.product.stock) {
      setState(() {
        _quantity++;
        _updateTotalPrice();
      });
    }
  }

  void _decrementQuantity() {
    if (_quantity > 1) {
      setState(() {
        _quantity--;
        _updateTotalPrice();
      });
    }
  }

  // Razorpay Payment Handlers
  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    setState(() {
      _isProcessing = false;
      _isSubmitting = false;
    });

    // After successful payment, place the order
    _placeOrder(response.paymentId);

    Fluttertoast.showToast(
      msg: "Payment Successful! 🎉",
      backgroundColor: Colors.green,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
      timeInSecForIosWeb: 2,
    );
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    setState(() {
      _isProcessing = false;
      _isSubmitting = false;
    });

    Fluttertoast.showToast(
      msg: "Payment Failed: ${response.message ?? 'Unknown error'}",
      backgroundColor: Colors.red,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
      timeInSecForIosWeb: 3,
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    setState(() {
      _isProcessing = false;
    });

    Fluttertoast.showToast(
      msg: "External Wallet: ${response.walletName}",
      backgroundColor: hennaBrown,
      textColor: Colors.white,
      gravity: ToastGravity.TOP,
    );
  }

  // Open Razorpay Checkout
  void _openCheckout() async {
    setState(() {
      _isProcessing = true;
      _isSubmitting = true;
    });

    // Get user details from SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    String? userPhone = prefs.getString('phone') ?? '9876543210';
    String? userEmail = prefs.getString('email') ?? 'user@example.com';
    String? userName = prefs.getString('user_name') ?? 'Customer';

    var options = {
      'key': 'rzp_test_HKCAwYtLt0rwQe', // Your Razorpay test key
      'amount': (_totalPrice * 100).round(), // Amount in paise
      'name': 'Mehandi Art Studio',
      'description': '${widget.product.name} - ${_quantity} item(s)',
      'prefill': {
        'contact': userPhone,
        'email': userEmail,
        'name': userName,
      },
      'theme': {
        'color': '#8B4C39' // Using hennaBrown color
      },
      'notes': {
        'product_id': widget.product.id.toString(),
        'quantity': _quantity.toString(),
        'user_id': prefs.getString('lid') ?? '',
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      setState(() {
        _isProcessing = false;
        _isSubmitting = false;
      });

      Fluttertoast.showToast(
        msg: "Payment initialization failed: ${e.toString()}",
        backgroundColor: Colors.red,
        textColor: Colors.white,
        gravity: ToastGravity.TOP,
      );
    }
  }

  // Place order after successful payment
  Future<void> _placeOrder(String? paymentId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('lid');

      if (userId == null) {
        _showSnackBar('User not logged in', Colors.red);
        return;
      }

      // Prepare order data with payment details
      Map<String, dynamic> orderData = {
        'product_id': widget.product.id.toString(),
        'user_id': userId,
        'quantity': _quantity.toString(),
        'total_price': _totalPrice.toString(),
        'status': 'confirmed', // Changed from 'pending' to 'confirmed' after payment
        'payment_id': paymentId ?? '',
        'payment_status': 'success',
        'payment_method': 'Razorpay',
      };

      final response = await http.post(
        Uri.parse('${widget.baseUrl}/myapp/place_order/'),
        body: orderData,
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const UserHomePage()),
        );        _showSuccessDialog(paymentId);
      } else {
        throw Exception(data['message'] ?? 'Failed to place order');
      }
    } catch (e) {
      _showSnackBar('Error placing order: $e', Colors.red);
    } finally {
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  void _showSuccessDialog(String? paymentId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          backgroundColor: hennaCream,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Success Icon
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaBrown, hennaGold],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                  ),
                  child: const Icon(
                    Iconsax.tick_circle,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),

                // Success Message
                const Text(
                  'Payment Successful!',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: hennaDeep,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Your order for ${widget.product.name} has been placed successfully.',
                  style: const TextStyle(color: hennaBrown),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),

                // Order Details
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: hennaLight,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Quantity:', style: TextStyle(color: hennaDeep)),
                          Text('$_quantity',
                              style: const TextStyle(fontWeight: FontWeight.bold, color: hennaDeep)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total Amount:', style: TextStyle(color: hennaDeep)),
                          Text('₹${_totalPrice.toStringAsFixed(2)}',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: hennaBrown, fontSize: 16),
                          ),
                        ],
                      ),
                      if (paymentId != null) ...[
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Payment ID:', style: TextStyle(color: hennaDeep)),
                            Expanded(
                              child: Text(
                                paymentId.length > 15 ? '...${paymentId.substring(paymentId.length - 12)}' : paymentId,
                                style: const TextStyle(fontSize: 12, color: hennaBrown),
                                textAlign: TextAlign.end,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // OK Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop(); // Close dialog
                      Navigator.of(context).pop(); // Close bottom sheet
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: hennaBrown,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text('OK'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Helper method to get full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = widget.baseUrl.endsWith('/') ? widget.baseUrl.substring(0, widget.baseUrl.length - 1) : widget.baseUrl;

    return '$baseUrl/$cleanPath';
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.85,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.shopping_cart, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'Place Your Order',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),

              // Scrollable Content
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      // Product Info
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            // Product Image
                            Container(
                              width: 70,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                image: widget.product.imageUrl != null
                                    ? DecorationImage(
                                  image: NetworkImage(
                                    _getFullImageUrl(widget.product.imageUrl),
                                  ),
                                  fit: BoxFit.cover,
                                )
                                    : null,
                                color: hennaLight,
                              ),
                              child: widget.product.imageUrl == null
                                  ? Icon(Icons.image, color: hennaGold, size: 35)
                                  : null,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.product.name,
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: hennaDeep,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'Price: ₹${widget.product.price.toStringAsFixed(2)}',
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: hennaBrown,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Quantity Selector
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Select Quantity',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: hennaLight,
                              borderRadius: BorderRadius.circular(25),
                              border: Border.all(color: hennaGold.withOpacity(0.5)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                // Decrement button
                                InkWell(
                                  onTap: _decrementQuantity,
                                  borderRadius: BorderRadius.circular(15),
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: _quantity > 1 ? hennaBrown : Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: const Icon(
                                      Icons.remove,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                ),

                                // Quantity display
                                Text(
                                  '$_quantity',
                                  style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: hennaDeep,
                                  ),
                                ),

                                // Increment button
                                InkWell(
                                  onTap: _incrementQuantity,
                                  borderRadius: BorderRadius.circular(15),
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: _quantity < widget.product.stock ? hennaBrown : Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: const Icon(
                                      Icons.add,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Available stock: ${widget.product.stock} items',
                            style: TextStyle(
                              fontSize: 14,
                              color: hennaBrown.withOpacity(0.8),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // Price Summary
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaLight, hennaCream],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(color: hennaGold.withOpacity(0.5)),
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'Price per item:',
                                  style: TextStyle(fontSize: 16, color: hennaDeep),
                                ),
                                Text(
                                  '₹${widget.product.price.toStringAsFixed(2)}',
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: hennaDeep),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'Quantity:',
                                  style: TextStyle(fontSize: 16, color: hennaDeep),
                                ),
                                Text(
                                  '$_quantity',
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: hennaDeep),
                                ),
                              ],
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Divider(color: hennaGold, thickness: 1),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'Total Amount:',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    color: hennaDeep,
                                  ),
                                ),
                                Text(
                                  '₹${_totalPrice.toStringAsFixed(2)}',
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.bold,
                                    color: hennaBrown,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),

                      // Payment Button
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaBrown, hennaDeep],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: hennaDeep.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: (_isProcessing || _isSubmitting) ? null : _openCheckout,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 18),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: _isProcessing || _isSubmitting
                              ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Text(
                                'Processing...',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: hennaGold,
                                ),
                              ),
                            ],
                          )
                              : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Iconsax.wallet, color: hennaGold, size: 20),
                              const SizedBox(width: 12),
                              const Text(
                                'Pay with Razorpay',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Security Note
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: hennaGold.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Icon(Iconsax.shield_tick, color: hennaBrown, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Secure payment powered by Razorpay. Your payment information is encrypted.',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: hennaDeep.withOpacity(0.7),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}