// view_product_orders_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

import 'artist_home.dart';

// Product Order Model Class
class ProductOrder {
  final int id;
  final int quantity;
  final double totalPrice;
  final DateTime orderDate;
  final String status;
  final int productId;
  final int userId;
  final String productName;
  final String? productImage;
  final double productPrice;
  final String userFname;
  final String userLname;
  final String userPhone;
  final String? userProfileImage;

  ProductOrder({
    required this.id,
    required this.quantity,
    required this.totalPrice,
    required this.orderDate,
    required this.status,
    required this.productId,
    required this.userId,
    required this.productName,
    this.productImage,
    required this.productPrice,
    required this.userFname,
    required this.userLname,
    required this.userPhone,
    this.userProfileImage,
  });

  factory ProductOrder.fromJson(Map<String, dynamic> json) {
    return ProductOrder(
      id: json['id'] ?? 0,
      quantity: int.tryParse(json['quantity'].toString()) ?? 0,
      totalPrice: double.tryParse(json['total_price'].toString()) ?? 0.0,
      orderDate: DateTime.tryParse(json['order_date'] ?? '') ?? DateTime.now(),
      status: json['status'] ?? 'pending',
      productId: json['product_id'] ?? 0,
      userId: json['user_id'] ?? 0,
      productName: json['product_name'] ?? 'Unknown Product',
      productImage: json['product_image'],
      productPrice: double.tryParse(json['product_price'].toString()) ?? 0.0,
      userFname: json['user_fname'] ?? '',
      userLname: json['user_lname'] ?? '',
      userPhone: json['user_phone'] ?? '',
      userProfileImage: json['user_profile_image'],
    );
  }

  String get userFullName => '$userFname $userLname';

  // Helper to get status color
  Color get statusColor {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      case 'completed':
        return Colors.blue;
      case 'processing':
        return Colors.purple;
      case 'shipped':
        return Colors.indigo;
      case 'delivered':
        return Colors.teal;
      default:
        return Colors.grey;
    }
  }

  // Helper to get status icon
  IconData get statusIcon {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Iconsax.tick_circle;
      case 'pending':
        return Iconsax.clock;
      case 'cancelled':
        return Iconsax.close_circle;
      case 'completed':
        return Iconsax.tick_circle;
      case 'processing':
        return Iconsax.refresh;
      case 'shipped':
        return Iconsax.truck;
      case 'delivered':
        return Iconsax.box_tick;
      default:
        return Iconsax.info_circle;
    }
  }

  // Helper to get status background color
  Color get statusBackgroundColor {
    return statusColor.withOpacity(0.1);
  }

  // Formatted order date
  String get formattedOrderDate {
    return DateFormat('MMM dd, yyyy • hh:mm a').format(orderDate);
  }

  // Formatted date for display
  String get displayDate {
    return DateFormat('dd MMM yyyy').format(orderDate);
  }

  // Formatted time for display
  String get displayTime {
    return DateFormat('hh:mm a').format(orderDate);
  }
}

class ViewProductOrdersPage extends StatefulWidget {
  const ViewProductOrdersPage({super.key});

  @override
  State<ViewProductOrdersPage> createState() => _ViewProductOrdersPageState();
}

class _ViewProductOrdersPageState extends State<ViewProductOrdersPage> {
  List<ProductOrder> _orders = [];
  List<ProductOrder> _filteredOrders = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';

  // Filter options
  String _selectedFilter = 'All';
  final List<String> _filterOptions = [
    'All',
    'Pending',
    'Confirmed',
    'Processing',
    'Shipped',
    'Delivered',
    'Completed',
    'Cancelled'
  ];

  // Date filter
  DateTime? _selectedDate;

  // Search controller
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Stats
  int _pendingCount = 0;
  int _confirmedCount = 0;
  int _processingCount = 0;
  int _shippedCount = 0;
  int _deliveredCount = 0;
  int _completedCount = 0;
  int _cancelledCount = 0;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchOrders();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  // Fetch all orders
  Future<void> _fetchOrders() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? artistId = prefs.getString('lid');

      if (artistId == null) {
        setState(() {
          _errorMessage = 'Artist not logged in';
          _isLoading = false;
        });
        return;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_product_orders/'),
        body: {'artist_id': artistId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _orders = (data['orders'] as List)
                .map((json) => ProductOrder.fromJson(json))
                .toList();
            _calculateStats();
            _applyFilters();
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load orders');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Calculate statistics
  void _calculateStats() {
    _pendingCount = _orders.where((o) => o.status.toLowerCase() == 'pending').length;
    _confirmedCount = _orders.where((o) => o.status.toLowerCase() == 'confirmed').length;
    _processingCount = _orders.where((o) => o.status.toLowerCase() == 'processing').length;
    _shippedCount = _orders.where((o) => o.status.toLowerCase() == 'shipped').length;
    _deliveredCount = _orders.where((o) => o.status.toLowerCase() == 'delivered').length;
    _completedCount = _orders.where((o) => o.status.toLowerCase() == 'completed').length;
    _cancelledCount = _orders.where((o) => o.status.toLowerCase() == 'cancelled').length;
  }

  // Apply filters
  void _applyFilters() {
    List<ProductOrder> filtered = List.from(_orders);

    // Apply status filter
    if (_selectedFilter != 'All') {
      filtered = filtered.where((order) =>
      order.status.toLowerCase() == _selectedFilter.toLowerCase()
      ).toList();
    }

    // Apply date filter
    if (_selectedDate != null) {
      filtered = filtered.where((order) {
        return order.orderDate.year == _selectedDate!.year &&
            order.orderDate.month == _selectedDate!.month &&
            order.orderDate.day == _selectedDate!.day;
      }).toList();
    }

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((order) =>
      order.userFullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          order.userPhone.contains(_searchQuery) ||
          order.productName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          order.id.toString().contains(_searchQuery)
      ).toList();
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => b.orderDate.compareTo(a.orderDate));

    setState(() {
      _filteredOrders = filtered;
    });
  }

  // Clear all filters
  void _clearFilters() {
    setState(() {
      _selectedFilter = 'All';
      _selectedDate = null;
      _searchController.clear();
      _searchQuery = '';
      _applyFilters();
    });
  }

  // Select date
  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: hennaBrown,
              onPrimary: Colors.white,
              surface: hennaCream,
              onSurface: hennaDeep,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _applyFilters();
      });
    }
  }

  // Update order status
  Future<void> _updateOrderStatus(int orderId, String newStatus) async {
    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/update_order_status/'),
        body: {
          'order_id': orderId.toString(),
          'status': newStatus,
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('Order ${newStatus.toLowerCase()} successfully', Colors.green);
        await _fetchOrders();
      } else {
        throw Exception(data['message'] ?? 'Failed to update status');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Show order details
  void _showOrderDetails(ProductOrder order) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildOrderDetailsSheet(order),
    );
  }

  // Show status update dialog
  void _showStatusUpdateDialog(ProductOrder order) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update Order Status'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildStatusOption(
                icon: Iconsax.clock,
                title: 'Pending',
                color: Colors.orange,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'pending');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.tick_circle,
                title: 'Confirm Order',
                color: Colors.green,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'confirmed');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.refresh,
                title: 'Processing',
                color: Colors.purple,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'processing');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.truck,
                title: 'Shipped',
                color: Colors.indigo,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'shipped');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.box_tick,
                title: 'Delivered',
                color: Colors.teal,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'delivered');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.tick_circle,
                title: 'Completed',
                color: Colors.blue,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'completed');
                },
              ),
              _buildStatusOption(
                icon: Iconsax.close_circle,
                title: 'Cancel Order',
                color: Colors.red,
                onTap: () {
                  Navigator.pop(context);
                  _updateOrderStatus(order.id, 'cancelled');
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
      ),
    );
  }

  Widget _buildStatusOption({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(0.1),
        child: Icon(icon, color: color),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(color == Colors.green ? Icons.check_circle : Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildStatsSection(),
          _buildFilterBar(),
          Expanded(
            child: _filteredOrders.isEmpty
                ? _buildEmptyWidget()
                : _buildOrdersList(),
          ),
        ],
      ),
    );
  }

  // App Bar with Back Button
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new),
        onPressed: () =>  Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ArtistHomePage()),
        )
      ),
      title: const Text(
        'Product Orders',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchOrders,
        ),
      ],
    );
  }

  // Stats Section
  Widget _buildStatsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Order Overview',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildStatCard(
                  label: 'Pending',
                  count: _pendingCount,
                  color: Colors.orange,
                  icon: Iconsax.clock,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Confirmed',
                  count: _confirmedCount,
                  color: Colors.green,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Processing',
                  count: _processingCount,
                  color: Colors.purple,
                  icon: Iconsax.refresh,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Shipped',
                  count: _shippedCount,
                  color: Colors.indigo,
                  icon: Iconsax.truck,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Delivered',
                  count: _deliveredCount,
                  color: Colors.teal,
                  icon: Iconsax.box_tick,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Completed',
                  count: _completedCount,
                  color: Colors.blue,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  label: 'Cancelled',
                  count: _cancelledCount,
                  color: Colors.red,
                  icon: Iconsax.close_circle,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Stat Card
  Widget _buildStatCard({
    required String label,
    required int count,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 14),
              const SizedBox(width: 4),
              Text(
                count.toString(),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  // Filter Bar
  Widget _buildFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by customer, product or order ID...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _applyFilters();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _applyFilters();
                });
              },
            ),
          ),
          const SizedBox(height: 12),

          // Filter Chips Row
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ..._filterOptions.map((filter) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(filter),
                      selected: _selectedFilter == filter,
                      onSelected: (selected) {
                        setState(() {
                          _selectedFilter = filter;
                          _applyFilters();
                        });
                      },
                      backgroundColor: Colors.white,
                      selectedColor: hennaGold,
                      checkmarkColor: hennaDeep,
                      labelStyle: TextStyle(
                        color: _selectedFilter == filter ? hennaDeep : hennaBrown,
                        fontWeight: _selectedFilter == filter ? FontWeight.bold : FontWeight.normal,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: _selectedFilter == filter ? hennaDeep : hennaGold.withOpacity(0.3),
                        ),
                      ),
                    ),
                  );
                }),

                // Date Filter Chip
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(
                    label: Text(
                      _selectedDate == null
                          ? 'Select Date'
                          : DateFormat('dd MMM yyyy').format(_selectedDate!),
                    ),
                    onPressed: _selectDate,
                    backgroundColor: _selectedDate != null ? hennaGold : Colors.white,
                    labelStyle: TextStyle(
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    avatar: Icon(
                      Iconsax.calendar,
                      size: 16,
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: hennaGold.withOpacity(0.3)),
                    ),
                  ),
                ),

                // Clear Filter Chip
                if (_selectedFilter != 'All' || _selectedDate != null || _searchQuery.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: const Text('Clear'),
                      onPressed: _clearFilters,
                      backgroundColor: hennaLight,
                      labelStyle: TextStyle(color: hennaBrown),
                      avatar: Icon(Iconsax.close_circle, size: 16, color: hennaBrown),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(color: hennaGold.withOpacity(0.3)),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Result count
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredOrders.length} orders found',
                  style: TextStyle(
                    color: hennaBrown,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Loading Indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading orders...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error Widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Empty Widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: hennaGold.withOpacity(0.1),
            ),
            child: Icon(
              Iconsax.box,
              size: 60,
              color: hennaGold,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'No Orders Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null
                ? 'No orders match your filters'
                : 'You have no product orders yet',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          if (_searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null)
            ElevatedButton(
              onPressed: _clearFilters,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Clear Filters'),
            ),
        ],
      ),
    );
  }

  // Orders List
  Widget _buildOrdersList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredOrders.length,
      itemBuilder: (context, index) {
        final order = _filteredOrders[index];
        return _buildOrderCard(order);
      },
    );
  }

  // Order Card
  Widget _buildOrderCard(ProductOrder order) {
    return GestureDetector(
      onTap: () => _showOrderDetails(order),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
          ),
          color: hennaCream,
          child: Column(
            children: [
              // Customer Info Header
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(18),
                    topRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  children: [
                    // Customer Avatar
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: hennaGold, width: 1.5),
                      ),
                      child: ClipOval(
                        child: order.userProfileImage != null
                            ? Image.network(
                          _getFullImageUrl(order.userProfileImage),
                          fit: BoxFit.cover,
                          width: 40,
                          height: 40,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: hennaLight,
                              child: Icon(Icons.person, size: 20, color: hennaGold),
                            );
                          },
                        )
                            : Container(
                          color: hennaLight,
                          child: Icon(Icons.person, size: 20, color: hennaGold),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            order.userFullName,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            order.userPhone,
                            style: TextStyle(
                              fontSize: 12,
                              color: hennaBrown,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: order.statusColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: order.statusColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            order.statusIcon,
                            size: 12,
                            color: order.statusColor,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '#${order.id}',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: order.statusColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Product Details
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    // Product Image
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: 60,
                        height: 60,
                        color: hennaLight,
                        child: order.productImage != null
                            ? Image.network(
                          _getFullImageUrl(order.productImage),
                          fit: BoxFit.cover,
                          width: 60,
                          height: 60,
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Icon(Icons.image, size: 30, color: hennaGold),
                            );
                          },
                        )
                            : Center(
                          child: Icon(Icons.image, size: 30, color: hennaGold),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            order.productName,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.box, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                'Qty: ${order.quantity}',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: hennaBrown,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Icon(Iconsax.money, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                '₹${order.totalPrice.toStringAsFixed(2)}',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: hennaBrown,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.clock, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                '${order.displayDate} at ${order.displayTime}',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Status and Action Bar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Status Badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: order.statusBackgroundColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: order.statusColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            order.statusIcon,
                            size: 14,
                            color: order.statusColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            order.status.toUpperCase(),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: order.statusColor,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Update Status Button
                    Row(
                      children: [
                        InkWell(
                          onTap: () => _showStatusUpdateDialog(order),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [hennaBrown, hennaDeep],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Row(
                              children: [
                                Icon(Iconsax.refresh, color: Colors.white, size: 14),
                                SizedBox(width: 4),
                                Text(
                                  'Update',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Icon(
                          Icons.arrow_forward_ios,
                          size: 14,
                          color: hennaBrown,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Order Details Bottom Sheet
  Widget _buildOrderDetailsSheet(ProductOrder order) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.receipt, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'Order Details',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),

              // Scrollable Content
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Order Status Banner
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: order.statusBackgroundColor,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: order.statusColor.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: order.statusColor.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                order.statusIcon,
                                color: order.statusColor,
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Order Status',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: hennaBrown,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    order.status.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: order.statusColor,
                                    ),
                                  ),
                                  Text(
                                    'Order ID: #${order.id}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: hennaBrown.withOpacity(0.7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Customer Information Card
                      _buildInfoCard(
                        title: 'Customer Information',
                        icon: Iconsax.user,
                        children: [
                          _buildInfoRow(Iconsax.user, 'Name', order.userFullName),
                          _buildInfoRow(Iconsax.call, 'Phone', order.userPhone),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Product Information Card
                      _buildInfoCard(
                        title: 'Product Details',
                        icon: Iconsax.box,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  width: 60,
                                  height: 60,
                                  color: hennaLight,
                                  child: order.productImage != null
                                      ? Image.network(
                                    _getFullImageUrl(order.productImage),
                                    fit: BoxFit.cover,
                                    width: 60,
                                    height: 60,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Center(
                                        child: Icon(Icons.image, size: 30, color: hennaGold),
                                      );
                                    },
                                  )
                                      : Center(
                                    child: Icon(Icons.image, size: 30, color: hennaGold),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      order.productName,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: hennaDeep,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Price: ₹${order.productPrice.toStringAsFixed(2)}',
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: hennaBrown,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Order Information Card
                      _buildInfoCard(
                        title: 'Order Information',
                        icon: Iconsax.receipt,
                        children: [
                          _buildInfoRow(Iconsax.box, 'Quantity', '${order.quantity} item(s)'),
                          _buildInfoRow(Iconsax.money, 'Unit Price', '₹${order.productPrice.toStringAsFixed(2)}'),
                          const Divider(height: 16,),
                          _buildInfoRow(
                            Iconsax.money,
                            'Total Amount',
                            '₹${order.totalPrice.toStringAsFixed(2)}',
                            isBold: true,
                            valueColor: hennaBrown,
                          ),
                          _buildInfoRow(Iconsax.calendar, 'Order Date', order.formattedOrderDate),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Update Status Button
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaBrown, hennaDeep],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _showStatusUpdateDialog(order);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Iconsax.refresh, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'Update Order Status',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Info Card Helper
  Widget _buildInfoCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: hennaBrown, size: 18),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: hennaDeep,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  // Info Row Helper
  Widget _buildInfoRow(IconData icon, String label, String value,
      {bool isBold = false, Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 16, color: hennaGold),
          const SizedBox(width: 8),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    color: hennaBrown.withOpacity(0.7),
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: isBold ? 15 : 13,
                    fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
                    color: valueColor ?? hennaDeep,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}