// view_artist_requests_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mehndi_flutter/user_chat.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import 'arti_chat.dart';
import 'artist_home.dart';

// Artist Request Model Class
class ArtistRequest {
  final int id;
  final DateTime bookingDate;
  final String bookingTime;
  final String status;
  final DateTime createdAt;
  final int artistId;
  final int userId;
  final double amount;
  final String userFname;
  final String userLname;
  final String userPhone;
  final String? userProfileImage;

  ArtistRequest({
    required this.id,
    required this.bookingDate,
    required this.bookingTime,
    required this.status,
    required this.createdAt,
    required this.artistId,
    required this.userId,
    required this.amount,
    required this.userFname,
    required this.userLname,
    required this.userPhone,
    this.userProfileImage,
  });

  factory ArtistRequest.fromJson(Map<String, dynamic> json) {
    return ArtistRequest(
      id: json['id'] ?? 0,
      bookingDate: DateTime.tryParse(json['booking_date'] ?? '') ?? DateTime.now(),
      bookingTime: json['booking_time'] ?? '',
      status: json['status'] ?? 'pending',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      artistId: json['artist_id'] ?? 0,
      userId: json['user_id'] ?? 0,
      amount: double.tryParse(json['amount'].toString()) ?? 0.0,
      userFname: json['user_fname'] ?? '',
      userLname: json['user_lname'] ?? '',
      userPhone: json['user_phone'] ?? '',
      userProfileImage: json['user_profile_image'],
    );
  }

  String get userFullName => '$userFname $userLname';

  // Helper to get status color
  Color get statusColor {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
      case 'refund':
        return Colors.red;
      case 'completed':
        return Colors.blue;
      case 'paid':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  // Helper to get status icon
  IconData get statusIcon {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Iconsax.tick_circle;
      case 'pending':
        return Iconsax.clock;
      case 'cancelled':
      case 'refund':
        return Iconsax.close_circle;
      case 'completed':
        return Iconsax.tick_circle;
      case 'paid':
        return Iconsax.wallet_3;
      default:
        return Iconsax.info_circle;
    }
  }

  // Helper to get status background color
  Color get statusBackgroundColor {
    return statusColor.withOpacity(0.1);
  }

  // Formatted booking date
  String get formattedBookingDate {
    return DateFormat('EEEE, MMMM dd, yyyy').format(bookingDate);
  }

  // Formatted created date
  String get formattedCreatedDate {
    return DateFormat('MMM dd, yyyy • hh:mm a').format(createdAt);
  }

  // Check if amount is pending
  bool get isAmountPending {
    return amount == 0 && status.toLowerCase() == 'pending';
  }

  // Check if amount is set
  bool get hasAmount {
    return amount > 0;
  }

  // Check if status is refund/cancelled
  bool get isRefunded {
    return status.toLowerCase() == 'refund' || status.toLowerCase() == 'cancelled';
  }
}

class ViewArtistRequestsPage extends StatefulWidget {
  const ViewArtistRequestsPage({super.key});

  @override
  State<ViewArtistRequestsPage> createState() => _ViewArtistRequestsPageState();
}

class _ViewArtistRequestsPageState extends State<ViewArtistRequestsPage> {
  List<ArtistRequest> _requests = [];
  List<ArtistRequest> _filteredRequests = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';

  // Filter options
  String _selectedFilter = 'All';
  final List<String> _filterOptions = ['All', 'Pending', 'Confirmed', 'Completed', 'Cancelled', 'Paid', 'Refund'];

  // Date filter
  DateTime? _selectedDate;

  // Search controller
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Stats
  int _pendingCount = 0;
  int _confirmedCount = 0;
  int _completedCount = 0;
  int _cancelledCount = 0;
  int _paidCount = 0;
  int _refundCount = 0;

  // Amount dialog controllers
  final TextEditingController _amountController = TextEditingController();

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchArtistRequests();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  // Fetch artist requests
  Future<void> _fetchArtistRequests() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? artistId = prefs.getString('lid');

      if (artistId == null) {
        setState(() {
          _errorMessage = 'Artist not logged in';
          _isLoading = false;
        });
        return;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_artist_requests/'),
        body: {'artist_id': artistId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _requests = (data['requests'] as List)
                .map((json) => ArtistRequest.fromJson(json))
                .toList();
            _calculateStats();
            _applyFilters();
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load requests');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Calculate statistics
  void _calculateStats() {
    _pendingCount = _requests.where((r) => r.status.toLowerCase() == 'pending').length;
    _confirmedCount = _requests.where((r) => r.status.toLowerCase() == 'confirmed').length;
    _completedCount = _requests.where((r) => r.status.toLowerCase() == 'completed').length;
    _cancelledCount = _requests.where((r) => r.status.toLowerCase() == 'cancelled').length;
    _paidCount = _requests.where((r) => r.status.toLowerCase() == 'paid').length;
    _refundCount = _requests.where((r) => r.status.toLowerCase() == 'refund').length;
  }

  // Apply filters
  void _applyFilters() {
    List<ArtistRequest> filtered = List.from(_requests);

    if (_selectedFilter != 'All') {
      filtered = filtered.where((request) =>
      request.status.toLowerCase() == _selectedFilter.toLowerCase()
      ).toList();
    }

    if (_selectedDate != null) {
      filtered = filtered.where((request) {
        return request.bookingDate.year == _selectedDate!.year &&
            request.bookingDate.month == _selectedDate!.month &&
            request.bookingDate.day == _selectedDate!.day;
      }).toList();
    }

    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((request) =>
      request.userFullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          request.userPhone.contains(_searchQuery) ||
          request.id.toString().contains(_searchQuery)
      ).toList();
    }

    filtered.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    setState(() {
      _filteredRequests = filtered;
    });
  }

  // Clear all filters
  void _clearFilters() {
    setState(() {
      _selectedFilter = 'All';
      _selectedDate = null;
      _searchController.clear();
      _searchQuery = '';
      _applyFilters();
    });
  }

  // Select date
  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: hennaBrown,
              onPrimary: Colors.white,
              surface: hennaCream,
              onSurface: hennaDeep,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _applyFilters();
      });
    }
  }

  // Navigate to chat
  void _navigateToChat(ArtistRequest request) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Arti_ChatPage(
          artistId: request.userId.toString(),
          artistName: request.userFullName,
        ),
      ),
    );
  }

  // Show amount dialog
  void _showAmountDialog(ArtistRequest request) {
    _amountController.clear();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Set Amount'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter the amount for this booking:'),
            const SizedBox(height: 16),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                prefixText: '₹ ',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(color: hennaBrown),
                ),
              ),
            ),
          ],
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: hennaBrown)),
          ),
          ElevatedButton(
            onPressed: () => _submitAmount(request.id),
            style: ElevatedButton.styleFrom(
              backgroundColor: hennaBrown,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }

  // Submit amount to server
  Future<void> _submitAmount(int requestId) async {
    String amountStr = _amountController.text.trim();
    if (amountStr.isEmpty) {
      Fluttertoast.showToast(
        msg: "Please enter an amount",
        backgroundColor: Colors.orange,
        textColor: Colors.white,
      );
      return;
    }

    double amount = double.tryParse(amountStr) ?? 0;
    if (amount <= 0) {
      Fluttertoast.showToast(
        msg: "Please enter a valid amount",
        backgroundColor: Colors.orange,
        textColor: Colors.white,
      );
      return;
    }

    Navigator.pop(context); // Close dialog

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/update_request_amount/'),
        body: {
          'request_id': requestId.toString(),
          'amount': amount.toString(),
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        Fluttertoast.showToast(
          msg: "Amount set successfully",
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
        await _fetchArtistRequests();
      } else {
        throw Exception(data['message'] ?? 'Failed to update amount');
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Error: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Update request status
  Future<void> _updateRequestStatus(int requestId, String newStatus) async {
    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/update_request_status/'),
        body: {
          'request_id': requestId.toString(),
          'status': newStatus,
        },
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        String message = "Request ";
        switch (newStatus.toLowerCase()) {
          case 'confirmed':
            message += "confirmed";
            break;
          case 'completed':
            message += "marked as completed";
            break;
          case 'paid':
            message += "marked as paid";
            break;
          case 'cancelled':
            message += "cancelled";
            break;
          case 'refund':
            message += "refunded";
            break;
          default:
            message += "updated";
        }
        message += " successfully";

        Fluttertoast.showToast(
          msg: message,
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
        await _fetchArtistRequests();
      } else {
        throw Exception(data['message'] ?? 'Failed to update status');
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Error: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Show status update dialog
  void _showStatusUpdateDialog(ArtistRequest request) {
    // Don't show status update for already refunded/cancelled requests
    if (request.isRefunded) {
      Fluttertoast.showToast(
        msg: "This request has already been ${request.status.toLowerCase()}",
        backgroundColor: Colors.orange,
        textColor: Colors.white,
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update Request Status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Confirm option (only for pending)
            if (request.status.toLowerCase() == 'pending')
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.green.withOpacity(0.1),
                  child: const Icon(Iconsax.tick_circle, color: Colors.green),
                ),
                title: const Text('Confirm Request'),
                onTap: () {
                  Navigator.pop(context);
                  _updateRequestStatus(request.id, 'confirmed');
                },
              ),

            // Complete option (for confirmed or paid)
            if (request.status.toLowerCase() == 'confirmed' ||
                request.status.toLowerCase() == 'paid')
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue.withOpacity(0.1),
                  child: const Icon(Iconsax.tick_circle, color: Colors.blue),
                ),
                title: const Text('Mark as Completed'),
                onTap: () {
                  Navigator.pop(context);
                  _updateRequestStatus(request.id, 'completed');
                },
              ),

            // Paid option (for confirmed)
            if (request.status.toLowerCase() == 'confirmed')
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.purple.withOpacity(0.1),
                  child: const Icon(Iconsax.wallet_3, color: Colors.purple),
                ),
                title: const Text('Mark as Paid'),
                onTap: () {
                  Navigator.pop(context);
                  _updateRequestStatus(request.id, 'paid');
                },
              ),

            // Cancel/Refund option (for pending, confirmed, or paid)
            if (request.status.toLowerCase() != 'completed' &&
                request.status.toLowerCase() != 'refund' &&
                request.status.toLowerCase() != 'cancelled')
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.red.withOpacity(0.1),
                  child: const Icon(Iconsax.close_circle, color: Colors.red),
                ),
                title: Text(request.hasAmount ? 'Process Refund' : 'Cancel Request'),
                subtitle: request.hasAmount ? Text('Refund amount to customer') : null,
                onTap: () {
                  Navigator.pop(context);
                  // Show confirmation dialog for refund/cancel
                  _showCancelConfirmationDialog(request);
                },
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
      ),
    );
  }

  // Show cancellation/refund confirmation dialog
  void _showCancelConfirmationDialog(ArtistRequest request) {
    bool hasAmount = request.hasAmount;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(hasAmount ? 'Process Refund' : 'Cancel Request'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              hasAmount ? Iconsax.wallet_3 : Iconsax.close_circle,
              size: 50,
              color: Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              hasAmount
                  ? 'Are you sure you want to refund ₹${request.amount.toStringAsFixed(2)} to the customer?'
                  : 'Are you sure you want to cancel this request?',
              textAlign: TextAlign.center,
            ),
            if (hasAmount)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'This action cannot be undone.',
                  style: TextStyle(
                    color: Colors.red.shade700,
                    fontSize: 12,
                  ),
                ),
              ),
          ],
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: hennaCream,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('No, Keep It'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // Close confirmation dialog
              // Update status to 'refund' for paid requests, 'cancelled' for others
              String newStatus = request.hasAmount ? 'refund' : 'cancelled';
              _updateRequestStatus(request.id, newStatus);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: Text(hasAmount ? 'Yes, Refund' : 'Yes, Cancel'),
          ),
        ],
      ),
    );
  }

  // Show request details
  void _showRequestDetails(ArtistRequest request) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildRequestDetailsSheet(request),
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(color == Colors.green ? Icons.check_circle : Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildStatsSection(),
          _buildFilterBar(),
          Expanded(
            child: _filteredRequests.isEmpty
                ? _buildEmptyWidget()
                : _buildRequestsList(),
          ),
        ],
      ),
    );
  }

  // App Bar with Back Button
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new),
        onPressed: () => Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const ArtistHomePage(),
          ),
        ),
      ),
      title: const Text(
        'Artist Requests',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchArtistRequests,
        ),
      ],
    );
  }

  // Stats Section
  Widget _buildStatsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Overview',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildStatCard(
                  label: 'Pending',
                  count: _pendingCount,
                  color: Colors.orange,
                  icon: Iconsax.clock,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Confirmed',
                  count: _confirmedCount,
                  color: Colors.green,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Completed',
                  count: _completedCount,
                  color: Colors.blue,
                  icon: Iconsax.tick_circle,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Paid',
                  count: _paidCount,
                  color: Colors.purple,
                  icon: Iconsax.wallet_3,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Cancelled',
                  count: _cancelledCount,
                  color: Colors.red,
                  icon: Iconsax.close_circle,
                ),
                const SizedBox(width: 12),
                _buildStatCard(
                  label: 'Refund',
                  count: _refundCount,
                  color: Colors.red.shade900,
                  icon: Iconsax.wallet_3,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Stat Card
  Widget _buildStatCard({
    required String label,
    required int count,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 4),
              Text(
                count.toString(),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  // Filter Bar
  Widget _buildFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by customer name or phone...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _applyFilters();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _applyFilters();
                });
              },
            ),
          ),
          const SizedBox(height: 12),

          // Filter Chips Row
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ..._filterOptions.map((filter) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(filter),
                      selected: _selectedFilter == filter,
                      onSelected: (selected) {
                        setState(() {
                          _selectedFilter = filter;
                          _applyFilters();
                        });
                      },
                      backgroundColor: Colors.white,
                      selectedColor: hennaGold,
                      checkmarkColor: hennaDeep,
                      labelStyle: TextStyle(
                        color: _selectedFilter == filter ? hennaDeep : hennaBrown,
                        fontWeight: _selectedFilter == filter ? FontWeight.bold : FontWeight.normal,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: _selectedFilter == filter ? hennaDeep : hennaGold.withOpacity(0.3),
                        ),
                      ),
                    ),
                  );
                }),
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(
                    label: Text(
                      _selectedDate == null
                          ? 'Select Date'
                          : DateFormat('dd MMM yyyy').format(_selectedDate!),
                    ),
                    onPressed: _selectDate,
                    backgroundColor: _selectedDate != null ? hennaGold : Colors.white,
                    labelStyle: TextStyle(
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    avatar: Icon(
                      Iconsax.calendar,
                      size: 16,
                      color: _selectedDate != null ? hennaDeep : hennaBrown,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: hennaGold.withOpacity(0.3)),
                    ),
                  ),
                ),
                if (_selectedFilter != 'All' || _selectedDate != null || _searchQuery.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: const Text('Clear'),
                      onPressed: _clearFilters,
                      backgroundColor: hennaLight,
                      labelStyle: TextStyle(color: hennaBrown),
                      avatar: Icon(Iconsax.close_circle, size: 16, color: hennaBrown),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(color: hennaGold.withOpacity(0.3)),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredRequests.length} requests found',
                  style: TextStyle(
                    color: hennaBrown,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Loading Indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading requests...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error Widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Empty Widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: hennaGold.withOpacity(0.1),
            ),
            child: Icon(
              Iconsax.calendar,
              size: 60,
              color: hennaGold,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'No Requests Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null
                ? 'No requests match your filters'
                : 'You have no booking requests yet',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          if (_searchQuery.isNotEmpty || _selectedFilter != 'All' || _selectedDate != null)
            ElevatedButton(
              onPressed: _clearFilters,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Clear Filters'),
            ),
        ],
      ),
    );
  }

  // Requests List
  Widget _buildRequestsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredRequests.length,
      itemBuilder: (context, index) {
        final request = _filteredRequests[index];
        return _buildRequestCard(request);
      },
    );
  }

  // Request Card
  Widget _buildRequestCard(ArtistRequest request) {
    return GestureDetector(
      onTap: () => _showRequestDetails(request),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
          ),
          color: hennaCream,
          child: Column(
            children: [
              // User Info Row
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    // User Profile Image
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: hennaGold, width: 2),
                      ),
                      child: ClipOval(
                        child: request.userProfileImage != null
                            ? Image.network(
                          _getFullImageUrl(request.userProfileImage),
                          fit: BoxFit.cover,
                          width: 60,
                          height: 60,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: hennaLight,
                              child: Icon(Icons.person, size: 30, color: hennaGold),
                            );
                          },
                        )
                            : Container(
                          color: hennaLight,
                          child: Icon(Icons.person, size: 30, color: hennaGold),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),

                    // User Details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            request.userFullName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.call, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                request.userPhone,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Iconsax.calendar, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                DateFormat('dd MMM yyyy').format(request.bookingDate),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Icon(Iconsax.clock, size: 12, color: hennaGold),
                              const SizedBox(width: 4),
                              Text(
                                request.bookingTime,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                          if (request.hasAmount) ...[
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(Iconsax.money, size: 12, color: hennaGold),
                                const SizedBox(width: 4),
                                Text(
                                  'Amount: ₹${request.amount.toStringAsFixed(2)}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: request.status.toLowerCase() == 'paid' ? Colors.green :
                                    request.isRefunded ? Colors.red : hennaBrown,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Action Buttons Bar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: hennaLight,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Status Badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: request.statusBackgroundColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: request.statusColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            request.statusIcon,
                            size: 14,
                            color: request.statusColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            request.status.toUpperCase(),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: request.statusColor,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Action Buttons
                    Row(
                      children: [
                        // Chat Button
                        InkWell(
                          onTap: () => _navigateToChat(request),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: hennaSage.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Iconsax.message,
                              color: hennaSage,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),

                        // Amount Button (only for pending requests without amount)
                        if (request.isAmountPending)
                          InkWell(
                            onTap: () => _showAmountDialog(request),
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: hennaGold.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Iconsax.money,
                                color: hennaGold,
                                size: 18,
                              ),
                            ),
                          ),

                        // More Options Button (disabled for refunded/cancelled)
                        if (!request.isRefunded)
                          InkWell(
                            onTap: () => _showStatusUpdateDialog(request),
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: hennaBrown.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Iconsax.more,
                                color: hennaBrown,
                                size: 18,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Request Details Bottom Sheet
  Widget _buildRequestDetailsSheet(ArtistRequest request) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: hennaCream,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: hennaGold, width: 2),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 60,
                height: 6,
                decoration: BoxDecoration(
                  color: hennaGold,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.calendar_1, color: hennaBrown, size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'Request Details',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(Iconsax.brush_1, color: hennaBrown, size: 24),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, hennaBrown],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),

              // Scrollable Content
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Customer Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Customer Information',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaDeep,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                // Customer Image
                                Container(
                                  width: 70,
                                  height: 70,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: hennaGold, width: 2),
                                  ),
                                  child: ClipOval(
                                    child: request.userProfileImage != null
                                        ? Image.network(
                                      _getFullImageUrl(request.userProfileImage),
                                      fit: BoxFit.cover,
                                      width: 70,
                                      height: 70,
                                      loadingBuilder: (context, child, loadingProgress) {
                                        if (loadingProgress == null) return child;
                                        return Center(
                                          child: CircularProgressIndicator(
                                            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                                          ),
                                        );
                                      },
                                      errorBuilder: (context, error, stackTrace) {
                                        return Container(
                                          color: hennaLight,
                                          child: Icon(Icons.person, size: 35, color: hennaGold),
                                        );
                                      },
                                    )
                                        : Container(
                                      color: hennaLight,
                                      child: Icon(Icons.person, size: 35, color: hennaGold),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        request.userFullName,
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: hennaDeep,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      _buildDetailRow(Iconsax.call, request.userPhone),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Request Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: hennaGold.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Request Information',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaDeep,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildDetailRow(Iconsax.calendar, 'Booking Date: ${request.formattedBookingDate}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.clock, 'Booking Time: ${request.bookingTime}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.receipt, 'Request ID: #${request.id}'),
                            const SizedBox(height: 8),
                            _buildDetailRow(Iconsax.calendar_1, 'Requested on: ${request.formattedCreatedDate}'),
                            if (request.hasAmount) ...[
                              const SizedBox(height: 8),
                              _buildDetailRow(
                                Iconsax.money,
                                'Amount: ₹${request.amount.toStringAsFixed(2)}',
                                isAmount: true,
                                amountColor: request.status.toLowerCase() == 'paid' ? Colors.green :
                                request.isRefunded ? Colors.red : hennaBrown,
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Status Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: request.statusBackgroundColor,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: request.statusColor.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: request.statusColor.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                request.statusIcon,
                                color: request.statusColor,
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Current Status',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: hennaDeep,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    request.status.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: request.statusColor,
                                    ),
                                  ),
                                  if (request.isRefunded)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        'This request has been ${request.status.toLowerCase()}',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: request.statusColor,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Action Buttons
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: hennaBrown,
                                side: const BorderSide(color: hennaBrown),
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: const Text('Close'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [hennaSage, hennaSage.withBlue(100)],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                ),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  _navigateToChat(request);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  foregroundColor: Colors.white,
                                  shadowColor: Colors.transparent,
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Iconsax.message, size: 20),
                                    SizedBox(width: 8),
                                    Text('Chat'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Set Amount Button (only for pending requests without amount)
                      if (request.isAmountPending)
                        SizedBox(
                          width: double.infinity,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [hennaGold, hennaBrown],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _showAmountDialog(request);
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                foregroundColor: Colors.white,
                                shadowColor: Colors.transparent,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Iconsax.money, size: 20),
                                  SizedBox(width: 8),
                                  Text('Set Amount'),
                                ],
                              ),
                            ),
                          ),
                        ),

                      // Cancel/Refund Button (for non-refunded/completed requests)
                      if (!request.isRefunded && request.status.toLowerCase() != 'completed')
                        Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _showCancelConfirmationDialog(request);
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    request.hasAmount ? Iconsax.wallet_3 : Iconsax.close_circle,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(request.hasAmount ? 'Process Refund' : 'Cancel Request'),
                                ],
                              ),
                            ),
                          ),
                        ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Detail Row Helper
  Widget _buildDetailRow(IconData icon, String text, {bool isAmount = false, Color? amountColor}) {
    return Row(
      children: [
        Icon(icon, size: 16, color: hennaGold),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              color: isAmount ? amountColor : hennaDeep,
              fontWeight: isAmount ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }
}