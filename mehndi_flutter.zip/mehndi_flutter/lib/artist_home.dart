import 'package:flutter/material.dart';
import 'package:mehndi_flutter/user_view_product_order.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'add_product.dart';
import 'arti_change_password.dart';
import 'arti_upload_design.dart';
import 'arti_view_profile.dart';
import 'arti_view_request.dart';
import 'ippage.dart';

class ArtistHomePage extends StatefulWidget {
  const ArtistHomePage({super.key});

  @override
  State<ArtistHomePage> createState() => _ArtistHomePageState();
}

class _ArtistHomePageState extends State<ArtistHomePage> {
  String _artistName = "Artist";
  String _profileImage = "";

  @override
  void initState() {
    super.initState();
    _loadArtistData();
  }

  Future<void> _loadArtistData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _artistName = prefs.getString('name') ?? 'Mehandi Artist';
      _profileImage = prefs.getString('profile_image') ?? '';
    });
  }

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaCream = Color(0xFFFFF8F2);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        title: const Text(
          'Artist Dashboard',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 4,
        actions: [
          // Profile icon with popup menu
          PopupMenuButton<String>(
            icon: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: hennaBrown),
            ),
            onSelected: (value) {
              switch (value) {
                case 'profile':
                  _viewProfile();
                  break;
                case 'change_password':
                  _changePassword();
                  break;
                case 'logout':
                  _logout();
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person_outline, color: hennaBrown),
                    SizedBox(width: 8),
                    Text('View Profile'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'change_password',
                child: Row(
                  children: [
                    Icon(Icons.lock_outline, color: hennaBrown),
                    SizedBox(width: 8),
                    Text('Change Password'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [hennaBrown, hennaGold],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: hennaBrown.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome back,',
                    style: TextStyle(
                      color: hennaLight.withOpacity(0.9),
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    _artistName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'Verified Artist',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),


            const SizedBox(height: 25),

            // Main Action Grid
            const Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.1,
              children: [
                _buildActionCard(
                  title: 'Upload Design',
                  icon: Icons.upload_file,
                  color: hennaBrown,
                  onTap: () => _navigateTo('upload_design'),
                ),
                _buildActionCard(
                  title: 'Add Product',
                  icon: Icons.add_business,
                  color: hennaGold,
                  onTap: () => _navigateTo('add_product'),
                ),
                _buildActionCard(
                  title: 'Design Bookings',
                  icon: Icons.assignment,
                  color: hennaDeep,
                  onTap: () => _navigateTo('design_bookings'),
                ),
                _buildActionCard(
                  title: 'Product Orders',
                  icon: Icons.shopping_cart,
                  color: hennaBrown,
                  onTap: () => _navigateTo('product_orders'),
                ),
              ],
            ),
            const SizedBox(height: 25),

            // Recent Activity Section
            // Container(
            //   padding: const EdgeInsets.all(16),
            //   decoration: BoxDecoration(
            //     color: hennaCream,
            //     borderRadius: BorderRadius.circular(20),
            //     border: Border.all(color: hennaGold.withOpacity(0.3)),
            //   ),
            //   child: Column(
            //     crossAxisAlignment: CrossAxisAlignment.start,
            //     children: [
            //       const Row(
            //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //         children: [
            //           Text(
            //             'Recent Activity',
            //             style: TextStyle(
            //               fontSize: 18,
            //               fontWeight: FontWeight.bold,
            //               color: hennaDeep,
            //             ),
            //           ),
            //           Icon(Icons.history, color: hennaBrown),
            //         ],
            //       ),
            //       const SizedBox(height: 16),
            //       _buildActivityItem(
            //         'New design booking from Priya',
            //         '2 hours ago',
            //         Icons.assignment_ind,
            //       ),
            //       _buildActivityItem(
            //         'Product order #1234 placed',
            //         '5 hours ago',
            //         Icons.shopping_bag,
            //       ),
            //       _buildActivityItem(
            //         'Your design was liked by 12 people',
            //         'yesterday',
            //         Icons.favorite,
            //       ),
            //     ],
            //   ),
            // ),
            const SizedBox(height: 20),

            // Tip of the Day
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [hennaGold.withOpacity(0.2), hennaCream],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: hennaGold),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lightbulb, color: hennaBrown),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Tip: Upload high-quality images of your mehandi designs to attract more clients!',
                      style: TextStyle(color: hennaDeep),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // Helper method to build stat cards
  Widget _buildStatCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: hennaGold.withOpacity(0.5)),
      ),
      child: Column(
        children: [
          Icon(icon, color: hennaBrown, size: 24),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  // Helper method to build action cards
  Widget _buildActionCard({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(color: hennaGold.withOpacity(0.5)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 32),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: hennaDeep,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build activity items
  Widget _buildActivityItem(String title, String time, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: hennaLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: hennaBrown, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    color: hennaDeep,
                  ),
                ),
                Text(
                  time,
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Navigation methods
  void _navigateTo(String page) {
    switch (page) {
      case 'upload_design':
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const AddDesignPage()),
        );
      // Navigate to upload design page
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Navigate to Upload Design')),
        );
        break;
      case 'add_product':
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ProductManagementPage()),
        );        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Navigate to Add Product')),
        );
        break;
      case 'design_bookings':
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ViewArtistRequestsPage()),
        );
        // Navigate to design bookings page
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Navigate to Design Bookings')),
        );
        break;
      case 'product_orders':
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ViewProductOrdersPage()),
        );        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Navigate to Product Orders')),
        );
        break;
    }
  }

  void _viewProfile() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const ArtistProfilePage()),
    );      ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Navigate to Profile')),
    );
  }

  void _changePassword() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const ChangePasswordPage()),
    );     ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Navigate to Change Password')),
    );
  }

  void _logout() async {
    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              // Clear shared preferences
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const IpSettingPage()),
              );

              // Navigate to login page

            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }
}

// Placeholder LoginPage class (replace with your actual login page)
class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Login Page'),
      ),
    );
  }
}