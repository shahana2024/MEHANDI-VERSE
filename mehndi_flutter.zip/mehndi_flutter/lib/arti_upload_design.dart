import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

// Import the view designs page
import 'arti_view_design.dart';
import 'artist_home.dart';

class AddDesignPage extends StatefulWidget {
  const AddDesignPage({super.key});

  @override
  State<AddDesignPage> createState() => _AddDesignPageState();
}

class _AddDesignPageState extends State<AddDesignPage> {
  final _formKey = GlobalKey<FormState>();

  // Text Controllers
  final TextEditingController designTypeController = TextEditingController();
  final TextEditingController handSizeController = TextEditingController();
  final TextEditingController coverageController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  // Image selection
  File? _designImage;
  final ImagePicker _picker = ImagePicker();

  // Loading state
  bool _isLoading = false;

  // Dropdown options
  final List<String> designTypes = [
    'Arabic',
    'Indian Traditional',
    'Rajasthani',
    'Gulf Style',
    'Indo-Western',
    'Bridal',
    'Minimalist',
    'Floral',
    'Geometric',
    'Custom'
  ];

  final List<String> handSizes = [
    'Full Hand',
    'Half Hand',
    'Wrist Only',
    'Fingers Only',
    'Backhand Only',
    'Palm Only',
    'Full Arm',
    'Custom'
  ];

  final List<String> coverageOptions = [
    'Light',
    'Medium',
    'Heavy',
    'Very Heavy',
    'Minimal',
    'Detailed'
  ];

  String? selectedDesignType;
  String? selectedHandSize;
  String? selectedCoverage;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color primaryColor = Color(0xFF6B4F3F);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => ArtistHomePage(),
              ),
            );
          },
        ),
        title: const Text(
          'Add New Design',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,

      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with icon
              Center(
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: hennaBrown.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                  ),
                  child: const Icon(
                    Icons.brush,
                    size: 50,
                    color: hennaBrown,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Center(
                child: Text(
                  'Upload Your Mehandi Design',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: hennaDeep,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Center(
                child: Text(
                  'Share your art with the community',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
              const SizedBox(height: 25),

              // View Designs Button - ADDED HERE
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 20),
                child: ElevatedButton.icon(
                  onPressed: _navigateToViewDesigns,
                  icon: const Icon(Icons.visibility, color: Colors.white),
                  label: const Text(
                    'View My Designs',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: hennaDeep,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                      side: BorderSide(color: hennaGold, width: 1.5),
                    ),
                    elevation: 3,
                  ),
                ),
              ),

              // Design Image Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: hennaCream,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: hennaGold.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: hennaBrown.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.image, color: hennaBrown, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Design Image',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: GestureDetector(
                        onTap: _pickImage,
                        child: Container(
                          width: double.infinity,
                          height: 200,
                          decoration: BoxDecoration(
                            color: hennaLight,
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(
                              color: hennaGold,
                              width: 2,
                              style: BorderStyle.solid,
                            ),
                            image: _designImage != null
                                ? DecorationImage(
                              image: FileImage(_designImage!),
                              fit: BoxFit.cover,
                            )
                                : null,
                          ),
                          child: _designImage == null
                              ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.add_photo_alternate,
                                size: 60,
                                color: hennaBrown.withOpacity(0.5),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'Tap to upload design image',
                                style: TextStyle(
                                  color: hennaBrown.withOpacity(0.7),
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                'JPG, PNG (Max 5MB)',
                                style: TextStyle(
                                  color: hennaGold,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          )
                              : null,
                        ),
                      ),
                    ),
                    if (_designImage != null) ...[
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.check_circle, color: hennaBrown, size: 16),
                          const SizedBox(width: 5),
                          Text(
                            'Image selected',
                            style: TextStyle(color: hennaDeep),
                          ),
                          const SizedBox(width: 15),
                          TextButton(
                            onPressed: _pickImage,
                            child: const Text('Change'),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Design Details Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: hennaCream,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: hennaGold.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: hennaBrown.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.info_outline, color: hennaBrown, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Design Details',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Design Type Dropdown
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: hennaLight,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: hennaGold.withOpacity(0.5)),
                      ),
                      child: DropdownButtonFormField<String>(
                        value: selectedDesignType,
                        decoration: const InputDecoration(
                          labelText: 'Design Type',
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.category, color: hennaBrown),
                        ),
                        items: designTypes.map((type) {
                          return DropdownMenuItem(
                            value: type,
                            child: Text(type),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedDesignType = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please select design type';
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Hand Size Dropdown
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: hennaLight,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: hennaGold.withOpacity(0.5)),
                      ),
                      child: DropdownButtonFormField<String>(
                        value: selectedHandSize,
                        decoration: const InputDecoration(
                          labelText: 'Hand Size',
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.back_hand, color: hennaBrown),
                        ),
                        items: handSizes.map((size) {
                          return DropdownMenuItem(
                            value: size,
                            child: Text(size),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedHandSize = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please select hand size';
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Coverage Dropdown
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: hennaLight,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: hennaGold.withOpacity(0.5)),
                      ),
                      child: DropdownButtonFormField<String>(
                        value: selectedCoverage,
                        decoration: const InputDecoration(
                          labelText: 'Coverage',
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.grid_view, color: hennaBrown),
                        ),
                        items: coverageOptions.map((coverage) {
                          return DropdownMenuItem(
                            value: coverage,
                            child: Text(coverage),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedCoverage = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please select coverage';
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Price Field
                    TextFormField(
                      controller: priceController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(color: hennaDeep),
                      decoration: InputDecoration(
                        labelText: 'Price (₹)',
                        labelStyle: const TextStyle(color: hennaBrown),
                        prefixIcon: const Icon(Icons.currency_rupee, color: hennaBrown),
                        filled: true,
                        fillColor: hennaLight,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(color: hennaGold),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: const BorderSide(color: hennaBrown, width: 2),
                        ),
                        hintText: 'e.g., 499',
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter price';
                        }
                        if (double.tryParse(value) == null) {
                          return 'Please enter a valid number';
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _submitDesign,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: hennaBrown,
                    foregroundColor: Colors.white,
                    elevation: 5,
                    shadowColor: hennaDeep,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(color: hennaGold, width: 2),
                    ),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(
                    strokeWidth: 3,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  )
                      : const Text(
                    'Upload Design',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // Navigate to View Designs Page
  void _navigateToViewDesigns() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ViewDesignsPage(),
      ),
    ).then((_) {
      // Optional: Refresh or perform any action when returning from view page
      print('Returned from view designs page');
    });
  }

  // Image picker method
  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 80,
      );

      if (image != null) {
        setState(() {
          _designImage = File(image.path);
        });
      }
    } catch (e) {
      print('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to pick image'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Submit design method
  Future<void> _submitDesign() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_designImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a design image'),
          backgroundColor: hennaBrown,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Get server URL from SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      String baseUrl = prefs.getString('url') ?? '';
      String? loginId = prefs.getString('lid');

      if (baseUrl.isEmpty) {
        _showError('Server URL not configured');
        return;
      }

      if (loginId == null) {
        _showError('Please login first');
        return;
      }

      // Prepare the request
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/myapp/upload_design/'), // Update with your actual endpoint
      );

      // Add text fields
      request.fields['lid'] = loginId;
      request.fields['design_type'] = selectedDesignType ?? '';
      request.fields['hand_size'] = selectedHandSize ?? '';
      request.fields['coverage'] = selectedCoverage ?? '';
      request.fields['price'] = priceController.text.trim();

      // Add image
      if (_designImage != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'design_image',
            _designImage!.path,
          ),
        );
      }

      // Send request
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var data = json.decode(responseData);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Success
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 10),
                Expanded(child: Text(data['message'] ?? 'Design uploaded successfully!')),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        );

        // Clear form after successful upload
        _clearForm();
      } else {
        _showError(data['error'] ?? 'Upload failed');
      }
    } catch (e) {
      print('Upload error: $e');
      _showError('Network error. Please try again.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _clearForm() {
    setState(() {
      _designImage = null;
      selectedDesignType = null;
      selectedHandSize = null;
      selectedCoverage = null;
      priceController.clear();
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }
}