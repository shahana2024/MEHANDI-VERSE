import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mehndi_flutter/login.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';

import 'artist_home.dart';

class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({super.key});

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final TextEditingController _currentPasswordController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _obscureCurrentPassword = true;
  bool _obscureNewPassword = true;
  bool _obscureConfirmPassword = true;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);
// Navigate back to ArtistHomePage
  void _navigateToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const ArtistHomePage(),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        leading: IconButton(
          icon: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
          onPressed: _navigateToHome, // Navigate to home on back press
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Header with Mehandi-inspired gradient
          _buildMehandiHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  // Decorative Henna Pattern
                  _buildHennaPattern(),
                  const SizedBox(height: 20),

                  // Password Form Section
                  _buildMehandiPasswordForm(),

                  // Bottom Decoration
                  const SizedBox(height: 20),
                  _buildBottomHennaPattern(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMehandiHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 60, 20, 30),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [hennaBrown, hennaDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(40),
          bottomRight: Radius.circular(40),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaDeep.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Back button with Mehandi style
          Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: hennaGold, width: 1),
                ),
                child: IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(
                    Icons.arrow_back_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  'Change Password',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(
                        color: hennaDeep.withOpacity(0.3),
                        offset: const Offset(2, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 30),

          // Mehandi-inspired design element
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildHennaDot(),
              Container(
                width: 60,
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaGold, Colors.transparent],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: hennaGold, width: 2),
                ),
                child: Icon(
                  Iconsax.lock_1,
                  size: 30,
                  color: hennaGold,
                ),
              ),
              Container(
                width: 60,
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, hennaGold],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
              _buildHennaDot(),
            ],
          ),
          const SizedBox(height: 20),

          // Description with Mehandi touch
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: hennaCream.withOpacity(0.2),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: hennaGold.withOpacity(0.3)),
              ),
              child: Text(
                'Secure your account with a new password',
                style: TextStyle(
                  fontSize: 15,
                  color: hennaCream,
                  fontWeight: FontWeight.w500,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHennaPattern() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          child: Column(
            children: [
              Icon(
                index.isEven ? Icons.circle : Icons.favorite,
                color: hennaGold.withOpacity(0.3),
                size: 12,
              ),
              const SizedBox(height: 4),
              Icon(
                index.isEven ? Icons.favorite : Icons.circle,
                color: hennaBrown.withOpacity(0.3),
                size: 8,
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildBottomHennaPattern() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.brush, color: hennaGold.withOpacity(0.2), size: 20),
        const SizedBox(width: 8),
        Container(
          width: 100,
          height: 2,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [hennaGold, hennaBrown, hennaGold],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
        ),
        const SizedBox(width: 8),
        Icon(Icons.brush, color: hennaBrown.withOpacity(0.2), size: 20),
      ],
    );
  }

  Widget _buildHennaDot() {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        color: hennaGold,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: hennaGold.withOpacity(0.5),
            blurRadius: 8,
            spreadRadius: 2,
          ),
        ],
      ),
    );
  }

  Widget _buildMehandiPasswordForm() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: hennaDeep.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
            spreadRadius: 5,
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        color: hennaCream,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
          side: BorderSide(color: hennaGold.withOpacity(0.5), width: 2),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // Section Header with Mehandi style
                Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [hennaBrown, hennaRose],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: hennaGold, width: 1),
                      ),
                      child: const Icon(
                        Iconsax.password_check,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Update Password',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: hennaDeep,
                            ),
                          ),
                          Text(
                            'Choose a strong password',
                            style: TextStyle(
                              fontSize: 13,
                              color: hennaBrown.withOpacity(0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),

                // Current Password Field
                _buildMehandiPasswordField(
                  controller: _currentPasswordController,
                  label: 'Current Password',
                  hint: 'Enter your current password',
                  obscureText: _obscureCurrentPassword,
                  onToggleVisibility: () {
                    setState(() {
                      _obscureCurrentPassword = !_obscureCurrentPassword;
                    });
                  },
                  icon: Iconsax.lock_1,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your current password';
                    }
                    if (value.length < 3) {
                      return 'Password must be at least 3 characters';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),

                // New Password Field
                _buildMehandiPasswordField(
                  controller: _newPasswordController,
                  label: 'New Password',
                  hint: 'Enter your new password',
                  obscureText: _obscureNewPassword,
                  onToggleVisibility: () {
                    setState(() {
                      _obscureNewPassword = !_obscureNewPassword;
                    });
                  },
                  icon: Iconsax.key,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a new password';
                    }
                    if (value.length < 8) {
                      return 'Password must be at least 8 characters';
                    }
                    if (!_isStrongPassword(value)) {
                      return 'Include uppercase, lowercase & numbers';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 8),

                // Password Strength Indicator with Mehandi colors
                _buildMehandiStrengthIndicator(),
                const SizedBox(height: 20),

                // Confirm Password Field
                _buildMehandiPasswordField(
                  controller: _confirmPasswordController,
                  label: 'Confirm Password',
                  hint: 'Re-enter your new password',
                  obscureText: _obscureConfirmPassword,
                  onToggleVisibility: () {
                    setState(() {
                      _obscureConfirmPassword = !_obscureConfirmPassword;
                    });
                  },
                  icon: Iconsax.security_safe,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please confirm your password';
                    }
                    if (value != _newPasswordController.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 30),

                // Update Button with Mehandi gradient
                Container(
                  width: double.infinity,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaBrown, hennaDeep],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: hennaDeep.withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _changePassword,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: _isLoading
                        ? SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(hennaGold),
                      ),
                    )
                        : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Iconsax.lock_1, size: 20, color: hennaGold),
                        const SizedBox(width: 12),
                        Text(
                          'UPDATE PASSWORD',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                            color: hennaGold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Password Requirements with Mehandi style
                _buildMehandiRequirements(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMehandiPasswordField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required bool obscureText,
    required VoidCallback onToggleVisibility,
    required IconData icon,
    required String? Function(String?) validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3), width: 1.5),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        style: const TextStyle(color: hennaDeep, fontSize: 15),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: hennaBrown, fontWeight: FontWeight.w500),
          hintText: hint,
          hintStyle: TextStyle(
            color: hennaBrown.withOpacity(0.4),
            fontSize: 13,
          ),
          prefixIcon: Icon(
            icon,
            color: hennaBrown,
            size: 22,
          ),
          suffixIcon: IconButton(
            icon: Icon(
              obscureText ? Iconsax.eye : Iconsax.eye_slash,
              color: hennaBrown,
              size: 20,
            ),
            onPressed: onToggleVisibility,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
        validator: validator,
        onChanged: (value) {
          if (controller == _newPasswordController) {
            setState(() {});
          }
        },
      ),
    );
  }

  Widget _buildMehandiStrengthIndicator() {
    final password = _newPasswordController.text;
    int strength = _calculatePasswordStrength(password);

    Color getColor() {
      if (strength == 0) return Colors.grey.shade400;
      if (strength == 1) return Colors.red.shade300;
      if (strength == 2) return Colors.orange.shade300;
      if (strength == 3) return hennaGold;
      return hennaBrown;
    }

    String getText() {
      if (strength == 0) return 'Enter a password';
      if (strength == 1) return 'Weak';
      if (strength == 2) return 'Fair';
      if (strength == 3) return 'Good';
      return 'Strong';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Iconsax.chart, size: 16, color: hennaBrown),
              const SizedBox(width: 8),
              Text(
                'Password Strength',
                style: TextStyle(
                  fontSize: 14,
                  color: hennaDeep,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Container(
                      height: 10,
                      decoration: BoxDecoration(
                        color: hennaGold.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    FractionallySizedBox(
                      widthFactor: strength / 4,
                      child: Container(
                        height: 10,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaGold, hennaBrown],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: hennaBrown.withOpacity(0.3),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: getColor().withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: getColor()),
                ),
                child: Text(
                  getText(),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: getColor(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMehandiRequirements() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: hennaLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: hennaBrown.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Iconsax.security_card,
                  color: hennaBrown,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'Password Requirements',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: hennaDeep,
                  fontSize: 15,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildMehandiRequirementItem(
            'At least 8 characters long',
            _newPasswordController.text.length >= 8,
          ),
          const SizedBox(height: 12),
          _buildMehandiRequirementItem(
            'Contains uppercase letters',
            _newPasswordController.text.contains(RegExp(r'[A-Z]')),
          ),
          const SizedBox(height: 12),
          _buildMehandiRequirementItem(
            'Contains lowercase letters',
            _newPasswordController.text.contains(RegExp(r'[a-z]')),
          ),
          const SizedBox(height: 12),
          _buildMehandiRequirementItem(
            'Contains numbers',
            _newPasswordController.text.contains(RegExp(r'[0-9]')),
          ),
        ],
      ),
    );
  }

  Widget _buildMehandiRequirementItem(String text, bool isMet) {
    return Row(
      children: [
        Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(
            gradient: isMet
                ? LinearGradient(
              colors: [hennaBrown, hennaGold],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )
                : null,
            color: isMet ? null : hennaLight,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isMet ? Colors.transparent : hennaGold.withOpacity(0.3),
              width: 1.5,
            ),
          ),
          child: isMet
              ? const Icon(
            Icons.check,
            color: Colors.white,
            size: 14,
          )
              : null,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 13,
              color: isMet ? hennaDeep : hennaBrown.withOpacity(0.5),
              fontWeight: isMet ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }

  int _calculatePasswordStrength(String password) {
    int strength = 0;
    if (password.length >= 8) strength++;
    if (password.contains(RegExp(r'[A-Z]'))) strength++;
    if (password.contains(RegExp(r'[a-z]'))) strength++;
    if (password.contains(RegExp(r'[0-9]'))) strength++;
    return strength;
  }

  bool _isStrongPassword(String password) {
    return password.length >= 8 &&
        password.contains(RegExp(r'[A-Z]')) &&
        password.contains(RegExp(r'[a-z]')) &&
        password.contains(RegExp(r'[0-9]'));
  }

  Future<void> _changePassword() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      String oldPassword = _currentPasswordController.text.trim();
      String newPassword = _newPasswordController.text.trim();
      String confirmPassword = _confirmPasswordController.text.trim();

      SharedPreferences sh = await SharedPreferences.getInstance();
      String url = sh.getString('url').toString();
      String lid = sh.getString('lid').toString();

      final urls = Uri.parse('$url/myapp/user_change_password/');

      try {
        final response = await http.post(urls, body: {
          'currentpassword': oldPassword,
          'newpassword': newPassword,
          'confirmpassword': confirmPassword,
          'lid': lid,
        });

        if (response.statusCode == 200) {
          String status = jsonDecode(response.body)['status'];
          if (status == 'ok') {
            _showMehandiSuccessDialog();
          } else {
            Fluttertoast.showToast(
              msg: 'Incorrect current password',
              backgroundColor: hennaDeep,
              textColor: Colors.white,
              gravity: ToastGravity.TOP,
            );
          }
        } else {
          Fluttertoast.showToast(
            msg: 'Network Error: ${response.statusCode}',
            backgroundColor: hennaDeep,
            textColor: Colors.white,
            gravity: ToastGravity.TOP,
          );
        }
      } catch (e) {
        Fluttertoast.showToast(
          msg: 'Connection Error: Please check your internet',
          backgroundColor: hennaDeep,
          textColor: Colors.white,
          gravity: ToastGravity.TOP,
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showMehandiSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          backgroundColor: hennaCream,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Success animation
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaBrown, hennaGold],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 3),
                  ),
                  child: const Icon(
                    Iconsax.tick_circle,
                    color: Colors.white,
                    size: 50,
                  ),
                ),
                const SizedBox(height: 20),

                // Henna pattern
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(3, (index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      child: Icon(
                        Icons.circle,
                        color: hennaGold.withOpacity(0.3),
                        size: 8,
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),

                Text(
                  'Password Updated!',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: hennaDeep,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Your password has been changed successfully.\nPlease login again with your new password.',
                  style: TextStyle(
                    fontSize: 14,
                    color: hennaBrown,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),

                // Decorative line
                Container(
                  width: 100,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaGold, hennaBrown],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Login again button
                Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [hennaBrown, hennaDeep],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: hennaDeep.withOpacity(0.3),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MehandiLoginPage(),
                        ),
                            (route) => false,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Iconsax.login_1, color: hennaGold),
                        const SizedBox(width: 12),
                        Text(
                          'LOGIN AGAIN',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: hennaGold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}