// mehndi_ai_recommendation.dart
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';

void main() {
  runApp(const MaterialApp(home: MehndiScreen()));
}

class MehndiScreen extends StatefulWidget {
  const MehndiScreen({super.key});

  @override
  State<MehndiScreen> createState() => _MehndiScreenState();
}

class _MehndiScreenState extends State<MehndiScreen> {
  File? _image;
  List<Map<String, dynamic>> recommendations = [];
  bool loading = false;
  String? _errorMessage;
  String _baseUrl = '';

  final ImagePicker picker = ImagePicker();

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    }
  }

  // Construct full image URL
  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  Future<void> pickImage() async {
    try {
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image == null) return;

      setState(() {
        _image = File(image.path);
        _errorMessage = null;
      });

      await sendToServer(_image!);
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to pick image: $e';
      });
    }
  }

  Future<void> sendToServer(File imageFile) async {
    if (_baseUrl.isEmpty) {
      setState(() {
        _errorMessage = 'Server URL not configured';
      });
      return;
    }

    setState(() {
      loading = true;
      recommendations.clear();
      _errorMessage = null;
    });

    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse("$_baseUrl/myapp/recommend-mehndi/"),
      );

      request.files.add(
        await http.MultipartFile.fromPath(
          'hand_image',
          imageFile.path,
        ),
      );

      var response = await request.send();

      if (response.statusCode == 200) {
        var data = await response.stream.bytesToString();
        var jsonData = json.decode(data);

        if (jsonData['status'] == 'success') {
          // Process recommendations to ensure full image URLs
          List<Map<String, dynamic>> processedRecommendations = [];

          for (var rec in jsonData['recommendations']) {
            // Create a new map with processed image URL
            Map<String, dynamic> processedRec = Map.from(rec);
            processedRec['image'] = _getFullImageUrl(rec['image']);
            processedRecommendations.add(processedRec);
          }

          setState(() {
            recommendations = processedRecommendations;
            loading = false;
          });
        } else {
          throw Exception(jsonData['message'] ?? 'Failed to get recommendations');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: $e';
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        title: const Text(
          "AI Mehndi Recommender",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Header Section
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [hennaCream, hennaLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: hennaGold.withOpacity(0.3)),
                boxShadow: [
                  BoxShadow(
                    color: hennaBrown.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: hennaGold.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Icon(Iconsax.chart_2, color: hennaBrown, size: 30),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'AI Recommendation',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Upload a hand image to get personalized mehndi designs',
                          style: TextStyle(
                            fontSize: 12,
                            color: hennaBrown,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Upload Button
            GestureDetector(
              onTap: pickImage,
              child: Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: hennaCream,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: hennaGold.withOpacity(0.5),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: hennaBrown.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: _image == null
                    ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: hennaGold.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Iconsax.image,
                        size: 50,
                        color: hennaBrown,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Tap to upload hand image',
                      style: TextStyle(
                        fontSize: 16,
                        color: hennaBrown,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'JPG, PNG accepted',
                      style: TextStyle(
                        fontSize: 12,
                        color: hennaBrown.withOpacity(0.7),
                      ),
                    ),
                  ],
                )
                    : Stack(
                  fit: StackFit.expand,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.file(
                        _image!,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        decoration: BoxDecoration(
                          color: hennaBrown,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 20,
                          ),
                          onPressed: () {
                            setState(() {
                              _image = null;
                              recommendations.clear();
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Error Message
            if (_errorMessage != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.error, color: Colors.red, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _errorMessage!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              ),

            // Loading Indicator
            if (loading)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: hennaGold, width: 2),
                      ),
                      child: const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                        strokeWidth: 3,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Analyzing your hand shape...',
                      style: TextStyle(
                        color: hennaBrown,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

            // Recommendations Section
            if (recommendations.isNotEmpty) ...[
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recommended Designs',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: hennaDeep,
                    ),
                  ),
                  Text(
                    '${recommendations.length} found',
                    style: TextStyle(
                      color: hennaBrown,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],

            // Recommendations List
            Expanded(
              child: recommendations.isEmpty && !loading && _image == null
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: hennaGold.withOpacity(0.1),
                      ),
                      child: Icon(
                        Iconsax.brush_1,
                        size: 60,
                        color: hennaGold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'No recommendations yet',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: hennaDeep,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Upload a hand image to get started',
                      style: TextStyle(
                        color: hennaBrown,
                      ),
                    ),
                  ],
                ),
              )
                  : ListView.builder(
                itemCount: recommendations.length,
                itemBuilder: (context, index) {
                  var design = recommendations[index];
                  return _buildRecommendationCard(design, index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendationCard(Map<String, dynamic> design, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
        ),
        color: hennaCream,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Rank Badge
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(18),
                  ),
                  child: Image.network(
                    design['image'] ?? '',
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(
                        height: 200,
                        color: hennaLight,
                        child: Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                          ),
                        ),
                      );
                    },
                    errorBuilder: (context, error, stackTrace) {
                      print("Error loading image: $error");
                      return Container(
                        height: 200,
                        color: hennaLight,
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.broken_image, color: hennaGold, size: 40),
                              const Text('Failed to load image'),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [hennaGold, hennaBrown],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: hennaDeep.withOpacity(0.3),
                          blurRadius: 5,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Icon(Iconsax.crown, color: Colors.white, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          '#${index + 1} Recommendation',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Design Details
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          design['name'] ?? 'Design Name',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: hennaGold.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                design['style'] ?? 'Traditional',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: hennaBrown,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Icon(Iconsax.star1, color: Colors.amber, size: 16),
                            const SizedBox(width: 4),
                            Text(
                              design['rating']?.toString() ?? '4.8',
                              style: TextStyle(
                                fontSize: 12,
                                color: hennaBrown,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [hennaBrown, hennaDeep],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Handle view design action
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Viewing ${design['name']}'),
                            backgroundColor: hennaBrown,
                          ),
                        );
                      },
                      child: const Row(
                        children: [
                          Icon(Iconsax.eye, color: Colors.white, size: 16),
                          SizedBox(width: 4),
                          Text(
                            'View',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}