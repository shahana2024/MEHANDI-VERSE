import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';

class IpSettingPage extends StatefulWidget {
  const IpSettingPage({super.key});

  @override
  State<IpSettingPage> createState() => _IpSettingPageState();
}

class _IpSettingPageState extends State<IpSettingPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController ipController = TextEditingController();

  // Mehandi-inspired color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaAccent = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaGold = Color(0xFFDBA27E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Top Icon and Title - Mehandi style
                Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: hennaGold.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        radius: 55,
                        backgroundColor: hennaBrown,
                        child: const Icon(
                          Icons.handshake_rounded,
                          size: 50,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [hennaBrown, hennaDeep],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: const Text(
                        'MehandiVerse',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: hennaGold.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: const Text(
                        'Artist Server Connection',
                        style: TextStyle(
                          fontSize: 16,
                          color: hennaDeep,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Connect to the mehandi art hub\nto sync designs and artist portfolios.',
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF5A3F2E),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
                const SizedBox(height: 40),

                // Decorative Henna Pattern (simple divider)
                Row(
                  children: [
                    Expanded(
                      child: Divider(
                        color: hennaGold,
                        thickness: 1.5,
                        indent: 10,
                        endIndent: 10,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: hennaLight,
                        shape: BoxShape.circle,
                        border: Border.all(color: hennaBrown, width: 2),
                      ),
                      child: const Icon(Icons.spa, color: hennaBrown, size: 20),
                    ),
                    Expanded(
                      child: Divider(
                        color: hennaGold,
                        thickness: 1.5,
                        indent: 10,
                        endIndent: 10,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),

                // Card Form with mehandi styling
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                    side: BorderSide(color: hennaGold.withOpacity(0.5), width: 1.5),
                  ),
                  elevation: 8,
                  shadowColor: hennaBrown.withOpacity(0.5),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        colors: [Colors.white, hennaLight.withOpacity(0.8)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // IP Input Field
                            TextFormField(
                              controller: ipController,
                              keyboardType: TextInputType.url,
                              style: const TextStyle(color: hennaDeep),
                              decoration: InputDecoration(
                                labelText: 'Server IP Address',
                                labelStyle: const TextStyle(color: hennaBrown),
                                hintText: 'e.g., 192.168.0.101',
                                hintStyle: TextStyle(color: hennaGold.withOpacity(0.7)),
                                prefixIcon: const Icon(Icons.router, color: hennaBrown),
                                filled: true,
                                fillColor: hennaLight,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: BorderSide(color: hennaGold),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(color: hennaBrown, width: 2),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a valid IP address';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 30),

                            // Connect Button with mehandi design
                            Container(
                              width: double.infinity,
                              height: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                boxShadow: [
                                  BoxShadow(
                                    color: hennaBrown.withOpacity(0.3),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: ElevatedButton.icon(
                                onPressed: _saveIP,
                                icon: const Icon(Icons.link, color: Colors.white),
                                label: const Text(
                                  'Connect to Mehandi Hub',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: hennaBrown,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 16),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30),
                                    side: BorderSide(color: hennaGold, width: 2),
                                  ),
                                  elevation: 0,
                                ),
                              ),
                            ),

                            const SizedBox(height: 20),

                            // Optional: decorative text
                            const Text(
                              '✽ secure artist connection ✽',
                              style: TextStyle(
                                color: hennaGold,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                // Footer with mehandi motif
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.circle, color: hennaGold, size: 8),
                        const SizedBox(width: 8),
                        Icon(Icons.circle, color: hennaBrown, size: 12),
                        const SizedBox(width: 8),
                        Icon(Icons.circle, color: hennaGold, size: 8),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'mehandiVerse · connect with henna artists',
                      style: TextStyle(
                        color: hennaDeep,
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '© 2026 mehandi art hub',
                      style: TextStyle(
                        color: hennaGold,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _saveIP() async {
    if (_formKey.currentState!.validate()) {
      String ip = ipController.text.trim();
      final sh = await SharedPreferences.getInstance();
      sh.setString("url", "http://$ip");

      // Show a mehandi-themed snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.spa, color: Colors.white, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Connected to server • $ip',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          backgroundColor: hennaBrown,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold, width: 1),
          ),
          duration: const Duration(seconds: 2),
        ),
      );

      // Navigate to welcome screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MehandiArtistApp()),
      );
    }
  }
}