// view_gallery_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lottie/lottie.dart';

// Design Model Class
class GalleryDesign {
  final int id;
  final int artistId;
  final String? imageUrl;
  final String designType;
  final String handSize;
  final String coverage;
  final double price;

  GalleryDesign({
    required this.id,
    required this.artistId,
    this.imageUrl,
    required this.designType,
    required this.handSize,
    required this.coverage,
    required this.price,
  });

  factory GalleryDesign.fromJson(Map<String, dynamic> json) {
    return GalleryDesign(
      id: json['id'] ?? 0,
      artistId: json['artist_id'] ?? 0,
      imageUrl: json['image_url'],
      designType: json['design_type'] ?? 'Unknown',
      handSize: json['hand_size'] ?? 'N/A',
      coverage: json['coverage'] ?? 'N/A',
      price: double.tryParse(json['price'].toString()) ?? 0.0,
    );
  }
}

class ViewGalleryPage extends StatefulWidget {
  final int? artistId;
  final String? artistName;

  const ViewGalleryPage({
    super.key,
    this.artistId,
    this.artistName,
  });

  @override
  State<ViewGalleryPage> createState() => _ViewGalleryPageState();
}

class _ViewGalleryPageState extends State<ViewGalleryPage> {
  List<GalleryDesign> _designs = [];
  List<GalleryDesign> _filteredDesigns = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';
  String _searchQuery = '';
  String _selectedFilter = 'All';
  bool _isGridView = true;

  final List<String> _filterOptions = ['All', 'Bridal', 'Arabic', 'Indian', 'Modern'];
  final TextEditingController _searchController = TextEditingController();

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchGallery();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  Future<void> _fetchGallery() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_gallery/'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          List<dynamic> designsJson = data['designs'];
          setState(() {
            _designs = designsJson
                .map((json) => GalleryDesign.fromJson(json))
                .where((design) =>
            widget.artistId == null || design.artistId == widget.artistId)
                .toList();
            _filteredDesigns = _designs;
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load gallery');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _filterDesigns() {
    setState(() {
      _filteredDesigns = _designs.where((design) {
        bool matchesSearch = _searchQuery.isEmpty ||
            design.designType.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            design.coverage.toLowerCase().contains(_searchQuery.toLowerCase());

        bool matchesFilter = _selectedFilter == 'All' ||
            design.designType.toLowerCase().contains(_selectedFilter.toLowerCase());

        return matchesSearch && matchesFilter;
      }).toList();
    });
  }

  void _showDesignDetails(GalleryDesign design) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildDesignDetailsSheet(design),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : Column(
        children: [
          _buildSearchAndFilterBar(),
          Expanded(
            child: _filteredDesigns.isEmpty
                ? _buildEmptyWidget()
                : _buildGalleryContent(),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Text(
        widget.artistName != null
            ? '${widget.artistName}\'s Gallery'
            : 'Mehandi Gallery',
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      backgroundColor: hennaBrown,
      foregroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      actions: [
        IconButton(
          icon: Icon(_isGridView ? Iconsax.element_4 : Iconsax.element_2),
          onPressed: () {
            setState(() {
              _isGridView = !_isGridView;
            });
          },
          tooltip: _isGridView ? 'List View' : 'Grid View',
        ),
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchGallery,
        ),
      ],
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/animations/henna_loading.json',
            width: 150,
            height: 150,
          ),
          const SizedBox(height: 20),
          Text(
            'Loading beautiful designs...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchAndFilterBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search designs...',
                hintStyle: TextStyle(color: hennaBrown.withOpacity(0.5)),
                prefixIcon: Icon(Icons.search, color: hennaBrown),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: hennaBrown),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _filterDesigns();
                    });
                  },
                )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _filterDesigns();
                });
              },
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _filterOptions.map((filter) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: _selectedFilter == filter,
                    onSelected: (selected) {
                      setState(() {
                        _selectedFilter = filter;
                        _filterDesigns();
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: hennaGold,
                    checkmarkColor: hennaDeep,
                    labelStyle: TextStyle(
                      color: _selectedFilter == filter ? hennaDeep : hennaBrown,
                      fontWeight: _selectedFilter == filter ? FontWeight.bold : FontWeight.normal,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: _selectedFilter == filter ? hennaDeep : hennaGold.withOpacity(0.3),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${_filteredDesigns.length} designs found',
                  style: TextStyle(
                    color: hennaBrown,
                    fontSize: 12,
                  ),
                ),
                if (widget.artistId != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: hennaGold.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'Artist Gallery',
                      style: TextStyle(
                        color: hennaDeep,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/animations/henna_empty.json',
            width: 200,
            height: 200,
          ),
          const SizedBox(height: 20),
          Text(
            'No Designs Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _searchQuery.isNotEmpty
                ? 'No designs match your search'
                : 'Check back later for new designs',
            style: TextStyle(color: hennaBrown),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildGalleryContent() {
    return _isGridView ? _buildGridView() : _buildListView();
  }

  Widget _buildGridView() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.75,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: _filteredDesigns.length,
      itemBuilder: (context, index) {
        final design = _filteredDesigns[index];
        return _buildGridCard(design);
      },
    );
  }

  Widget _buildListView() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredDesigns.length,
      itemBuilder: (context, index) {
        final design = _filteredDesigns[index];
        return _buildListCard(design);
      },
    );
  }

  Widget _buildGridCard(GalleryDesign design) {
    return GestureDetector(
      onTap: () => _showDesignDetails(design),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
          ),
          color: hennaCream,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 3,
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(18),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(
                        color: hennaLight,
                        child: design.imageUrl != null
                            ? Image.network(
                          _getFullImageUrl(design.imageUrl),
                          fit: BoxFit.cover,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Icon(Icons.broken_image, size: 40, color: hennaGold),
                            );
                          },
                        )
                            : Center(
                          child: Icon(Icons.image, size: 40, color: hennaGold),
                        ),
                      ),
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: hennaDeep.withOpacity(0.9),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: hennaGold, width: 1),
                          ),
                          child: Text(
                            '₹${design.price.toStringAsFixed(0)}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        design.designType,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: hennaDeep,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Row(
                        children: [
                          Icon(Iconsax.maximize, size: 10, color: hennaGold),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              'Size: ${design.handSize}',
                              style: TextStyle(fontSize: 10, color: hennaBrown),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(Iconsax.grid_2, size: 10, color: hennaGold),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              design.coverage,
                              style: TextStyle(fontSize: 10, color: hennaBrown),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildListCard(GalleryDesign design) {
    return GestureDetector(
      onTap: () => _showDesignDetails(design),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: hennaGold.withOpacity(0.3), width: 1.5),
          ),
          color: hennaCream,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.horizontal(
                  left: Radius.circular(18),
                ),
                child: Container(
                  width: 120,
                  height: 120,
                  color: hennaLight,
                  child: design.imageUrl != null
                      ? Image.network(
                    _getFullImageUrl(design.imageUrl),
                    fit: BoxFit.cover,
                    width: 120,
                    height: 120,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                        ),
                      );
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return Center(
                        child: Icon(Icons.broken_image, size: 30, color: hennaGold),
                      );
                    },
                  )
                      : Center(
                    child: Icon(Icons.image, size: 30, color: hennaGold),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              design.designType,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: hennaDeep,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: hennaBrown,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Text(
                              '₹${design.price.toStringAsFixed(0)}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Iconsax.maximize, size: 14, color: hennaGold),
                          const SizedBox(width: 8),
                          Text(
                            'Size: ${design.handSize}',
                            style: TextStyle(
                              fontSize: 13,
                              color: hennaBrown,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Iconsax.grid_2, size: 14, color: hennaGold),
                          const SizedBox(width: 8),
                          Text(
                            'Coverage: ${design.coverage}',
                            style: TextStyle(
                              fontSize: 13,
                              color: hennaBrown,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: hennaGold.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'View Details',
                              style: TextStyle(
                                fontSize: 11,
                                color: hennaDeep,
                              ),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_forward, size: 12, color: hennaDeep),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDesignDetailsSheet(GalleryDesign design) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
        border: Border.all(color: hennaGold, width: 2),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 60,
            height: 6,
            decoration: BoxDecoration(
              color: hennaGold,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            flex: 3,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: hennaGold, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: hennaDeep.withOpacity(0.3),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(27),
                child: design.imageUrl != null
                    ? Image.network(
                  _getFullImageUrl(design.imageUrl),
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: double.infinity,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                      ),
                    );
                  },
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: hennaLight,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.broken_image, size: 50, color: hennaGold),
                          const Text('Failed to load image'),
                        ],
                      ),
                    );
                  },
                )
                    : Container(
                  color: hennaLight,
                  child: Center(
                    child: Icon(Icons.image, size: 50, color: hennaGold),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          design.designType,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: hennaDeep,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaBrown, hennaDeep],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(
                          '₹${design.price.toStringAsFixed(0)}',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: 1.2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      children: [
                        _buildDetailItem(
                          icon: Iconsax.maximize,
                          label: 'Hand Size',
                          value: design.handSize,
                        ),
                        _buildDetailItem(
                          icon: Iconsax.grid_2,
                          label: 'Coverage',
                          value: design.coverage,
                        ),
                        _buildDetailItem(
                          icon: Iconsax.user,
                          label: 'Artist ID',
                          value: '#${design.artistId}',
                        ),
                        _buildDetailItem(
                          icon: Iconsax.tag,
                          label: 'Design ID',
                          value: '#${design.id}',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: hennaBrown,
                            side: BorderSide(color: hennaBrown),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: const Text('Close'),
                        ),
                      ),
                     
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: hennaLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: hennaGold),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: hennaBrown,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  void _showBookingDialog(GalleryDesign design) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Book This Design'),
        content: Text(
          'Would you like to book this ${design.designType} design?',
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        backgroundColor: hennaCream,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: hennaGold)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Booking feature coming soon!'),
                  backgroundColor: hennaBrown,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: hennaBrown,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }
}