// user_home_page.dart
import 'package:flutter/material.dart';
import 'package:mehndi_flutter/ippage.dart';
import 'package:mehndi_flutter/user_change_password.dart';
import 'package:mehndi_flutter/user_profile.dart';
import 'package:mehndi_flutter/user_view_artist.dart';
import 'package:mehndi_flutter/user_view_artist_request.dart';
import 'package:mehndi_flutter/user_view_order.dart';
import 'package:mehndi_flutter/user_view_product.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iconsax/iconsax.dart';

import 'complaint.dart';
import 'main.dart';

class UserHomePage extends StatefulWidget {
  const UserHomePage({super.key});

  @override
  State<UserHomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  String _userName = "User";
  String _greeting = "";
  bool _isLoading = false;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _setGreeting();
  }

  void _setGreeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      _greeting = "Good Morning";
    } else if (hour < 17) {
      _greeting = "Good Afternoon";
    } else {
      _greeting = "Good Evening";
    }
  }

  Future<void> _loadUserData() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _userName = prefs.getString('name') ?? 'User';
      });
    } catch (e) {
      print('Error loading user data: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        backgroundColor: hennaLight,
        titleTextStyle: const TextStyle(
          color: hennaDeep,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: const TextStyle(color: hennaBrown),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: hennaGold)),
          ),
          ElevatedButton(
            onPressed: () =>  Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (_) => const IpSettingPage()),
    ),
            style: ElevatedButton.styleFrom(
              backgroundColor: hennaBrown,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      drawer: _buildDrawer(),
      body: _isLoading
          ? _buildLoadingIndicator()
          : CustomScrollView(
        slivers: [
          // Enhanced App Bar with Gradient
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            backgroundColor: hennaBrown,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaBrown, hennaDeep, hennaBrown],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(40),
                    bottomRight: Radius.circular(40),
                  ),
                ),
                child: Stack(
                  children: [
                    // Decorative Pattern
                    Positioned(
                      top: -50,
                      right: -50,
                      child: Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: hennaGold.withOpacity(0.1),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: -30,
                      left: -30,
                      child: Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: hennaCream.withOpacity(0.1),
                        ),
                      ),
                    ),
                    // Header Content
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: hennaGold.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: const Icon(
                                  Icons.brush,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                'Mehandi Art Studio',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _greeting,
                                      style: TextStyle(
                                        color: hennaGold,
                                        fontSize: 14,
                                      ),
                                    ),
                                    Text(
                                      "Hi User $_userName",
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 28,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                  color: hennaGold.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: hennaGold.withOpacity(0.5),
                                  ),
                                ),
                                child: const Icon(
                                  Iconsax.user,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            leading: Builder(
              builder: (context) => IconButton(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: hennaGold.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: hennaGold, width: 1),
                  ),
                  child: const Icon(Icons.menu, color: Colors.white),
                ),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
            ),
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 16),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: hennaGold, width: 1),
                ),
                child: Stack(
                  children: [
                    // const Icon(Icons.notifications_none, color: Colors.white),
                    // Positioned(
                    //   top: 0,
                    //   right: 0,
                    //   child: Container(
                    //     width: 8,
                    //     height: 8,
                    //     decoration: const BoxDecoration(
                    //       color: Colors.red,
                    //       shape: BoxShape.circle,
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              ),
            ],
          ),

          // Quick Stats Section
          // SliverToBoxAdapter(
          //   child: _buildQuickStats(),
          // ),

          // Features Grid Title
          SliverToBoxAdapter(
            child: _buildSectionTitle('Explore Services', Iconsax.element_4),
          ),

          // Features Grid
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.1,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final features = _getFeatures();
                  return _buildFeatureCard(features[index]);
                },
                childCount: _getFeatures().length,
              ),
            ),
          ),

          // Special Offers Section
          SliverToBoxAdapter(
            child: _buildSpecialOffers(),
          ),

          // Bottom Padding
          const SliverToBoxAdapter(
            child: SizedBox(height: 20),
          ),
        ],
      ),
    );
  }

  // Quick Stats Section
  Widget _buildQuickStats() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [hennaCream, hennaLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem(
            icon: Iconsax.brush_1,
            value: '50+',
            label: 'Artists',
            color: hennaBrown,
          ),
          Container(
            height: 40,
            width: 1,
            color: hennaGold.withOpacity(0.3),
          ),
          _buildStatItem(
            icon: Iconsax.gallery,
            value: '200+',
            label: 'Designs',
            color: hennaRose,
          ),
          Container(
            height: 40,
            width: 1,
            color: hennaGold.withOpacity(0.3),
          ),
          _buildStatItem(
            icon: Iconsax.people,
            value: '1k+',
            label: 'Happy Clients',
            color: hennaSage,
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: hennaDeep,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: hennaBrown.withOpacity(0.7),
          ),
        ),
      ],
    );
  }

  // Section Title Builder
  Widget _buildSectionTitle(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: hennaBrown, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
        ],
      ),
    );
  }

  // Special Offers Section
  Widget _buildSpecialOffers() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [hennaBrown, hennaDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: hennaDeep.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Iconsax.discount_shape,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Special Offers',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildOfferCard(
                  title: '20% Off',
                  subtitle: 'on First Booking',
                  icon: Iconsax.calendar,
                ),
                const SizedBox(width: 12),
                _buildOfferCard(
                  title: 'Free Design',
                  subtitle: 'with Product Purchase',
                  icon: Iconsax.brush_2,
                ),
                const SizedBox(width: 12),
                _buildOfferCard(
                  title: 'Refer & Earn',
                  subtitle: 'Get ₹100 Credit',
                  icon: Iconsax.people,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOfferCard({
    required String title,
    required String subtitle,
    required IconData icon,
  }) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: hennaGold, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(
              color: hennaGold.withOpacity(0.9),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // Drawer Widget
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: hennaLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(30)),
      ),
      child: Column(
        children: [
          // Enhanced Drawer Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 30),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [hennaBrown, hennaDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                // Animated Profile Icon
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 3),
                    gradient: LinearGradient(
                      colors: [hennaGold.withOpacity(0.2), hennaCream.withOpacity(0.1)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const Center(
                    child: Icon(
                      Iconsax.user,
                      color: Colors.white,
                      size: 45,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _userName,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    color: hennaGold.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'Customer',
                    style: TextStyle(
                      fontSize: 13,
                      color: hennaGold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Drawer Items with Categories
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                const SizedBox(height: 10),
                _buildDrawerCategory('Main Menu'),
                _buildDrawerItem(
                  icon: Iconsax.home,
                  title: 'Home',
                  onTap: () => Navigator.pop(context),
                ),
                _buildDrawerItem(
                  icon: Iconsax.profile_circle,
                  title: 'My Profile',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ProfilePage()),
                    );
                  },
                ),

                _buildDrawerCategory('Services'),
                _buildDrawerItem(
                  icon: Iconsax.brush_1,
                  title: 'View Artists',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const UserViewArtistPage()),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: Iconsax.shopping_bag,
                  title: 'Products',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ViewProductsPage()),
                    );
                  },
                ),

                _buildDrawerCategory('Your Activity'),
                _buildDrawerItem(
                  icon: Iconsax.calendar,
                  title: 'My Bookings',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ViewBookingsPage()),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: Iconsax.people,
                  title: 'Artist Requests',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ViewArtistBookingsPage()),
                    );
                  },
                ),

                _buildDrawerCategory('Support'),
                _buildDrawerItem(
                  icon: Iconsax.message,
                  title: 'Send Complaint',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ComplaintPage()),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: Iconsax.chart,
                  title: 'AI Recommendation',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const MehndiScreen()),
                    );
                  },
                ),

                _buildDrawerCategory('Settings'),
                _buildDrawerItem(
                  icon: Iconsax.lock,
                  title: 'Change Password',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const user_ChangePasswordPage()),
                    );
                  },
                ),

                const Divider(color: hennaGold, thickness: 1, indent: 20, endIndent: 20),

                _buildDrawerItem(
                  icon: Iconsax.logout,
                  title: 'Logout',
                  color: Colors.red,
                  onTap: _logout,
                ),
              ],
            ),
          ),

          // Drawer Footer
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: hennaGold.withOpacity(0.2)),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: hennaGold.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.brush, color: hennaGold, size: 14),
                ),
                const SizedBox(width: 8),
                Text(
                  'Version 1.0.0',
                  style: TextStyle(
                    color: hennaBrown.withOpacity(0.6),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerCategory(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: hennaBrown.withOpacity(0.7),
          letterSpacing: 1,
        ),
      ),
    );
  }

  // Drawer Item Helper
  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: (color ?? hennaBrown).withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color ?? hennaBrown, size: 20),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: color ?? hennaDeep,
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
      ),
      trailing: Icon(Icons.arrow_forward_ios, size: 14, color: hennaGold),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  // Loading Indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading your Mehandi world...',
            style: TextStyle(
              color: hennaBrown,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // Feature Card
  Widget _buildFeatureCard(Feature feature) {
    return InkWell(
      onTap: feature.onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: feature.colors ?? [hennaCream, hennaLight],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: hennaGold.withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: (feature.iconColor ?? hennaBrown).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                feature.icon,
                color: feature.iconColor ?? hennaBrown,
                size: 28,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              feature.title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: hennaDeep,
              ),
              textAlign: TextAlign.center,
            ),
            if (feature.subtitle != null) ...[
              const SizedBox(height: 4),
              Text(
                feature.subtitle!,
                style: TextStyle(
                  fontSize: 11,
                  color: hennaBrown.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
      ),
    );
  }

  // Features Data
  List<Feature> _getFeatures() {
    return [
      Feature(
        icon: Iconsax.brush_1,
        title: 'Artists',
        subtitle: 'Browse artists',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const UserViewArtistPage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.shop,
        title: 'Products',
        subtitle: 'Shop essentials',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ViewProductsPage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.calendar_1,
        title: 'Bookings',
        subtitle: 'Your appointments',
        colors: [hennaLight, hennaCream],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ViewBookingsPage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.people,
        title: 'Requests',
        subtitle: 'Pending requests',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ViewArtistBookingsPage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.message_text,
        title: 'Complaints',
        subtitle: 'Send feedback',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ComplaintPage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.chart_2,
        title: 'AI Recommend',
        subtitle: 'Personalized',
        iconColor: hennaRose,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const MehndiScreen()),
          );
        },
      ),
      Feature(
        icon: Iconsax.profile_circle,
        title: 'Profile',
        subtitle: 'View & edit',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ProfilePage()),
          );
        },
      ),
      Feature(
        icon: Iconsax.lock,
        title: 'Security',
        subtitle: 'Change password',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const user_ChangePasswordPage()),
          );
        },
      ),
    ];
  }
}

// Feature Model Class
class Feature {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;
  final List<Color>? colors;
  final Color? iconColor;

  Feature({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.onTap,
    this.colors,
    this.iconColor,
  });
}