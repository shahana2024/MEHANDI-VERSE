import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class ArtistRegisterPage extends StatefulWidget {
  const ArtistRegisterPage({super.key});

  @override
  State<ArtistRegisterPage> createState() => _ArtistRegisterPageState();
}

class _ArtistRegisterPageState extends State<ArtistRegisterPage> {
  final _formKey = GlobalKey<FormState>();

  // Text Controllers for all fields
  final TextEditingController idController = TextEditingController();
  final TextEditingController fnameController = TextEditingController();
  final TextEditingController lnameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController experienceController = TextEditingController();
  final TextEditingController specializationController = TextEditingController();
  final TextEditingController bioController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController pincodeController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  // Profile image
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaCream = Color(0xFFFFF8F2);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        title: const Text(
          'Artist Registration',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 4,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Header with icon
              Center(
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: hennaBrown.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                  ),
                  child: const Icon(
                    Icons.brush,
                    size: 50,
                    color: hennaBrown,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Join as Mehandi Artist',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: hennaDeep,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Showcase your henna art to the world',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              ),
              const SizedBox(height: 25),

              // Profile Image Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: hennaCream,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: hennaGold.withOpacity(0.5)),
                ),
                child: Column(
                  children: [
                    const Text(
                      'Profile Photo',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: hennaDeep,
                      ),
                    ),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          color: hennaLight,
                          borderRadius: BorderRadius.circular(60),
                          border: Border.all(color: hennaGold, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: hennaBrown.withOpacity(0.2),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: _profileImage != null
                            ? ClipRRect(
                          borderRadius: BorderRadius.circular(60),
                          child: Image.file(
                            _profileImage!,
                            fit: BoxFit.cover,
                          ),
                        )
                            : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.camera_alt,
                              size: 40,
                              color: hennaBrown.withOpacity(0.6),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Upload',
                              style: TextStyle(
                                color: hennaBrown,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Personal Information Card
              _buildSectionCard(
                title: 'Personal Information',
                icon: Icons.person_outline,
                children: [
                  _buildTextField(
                    controller: idController,
                    label: 'Email',
                    icon: Icons.badge,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter Email ID';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: fnameController,
                    label: 'First Name',
                    icon: Icons.person,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter first name';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: lnameController,
                    label: 'Last Name',
                    icon: Icons.person_outline,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter last name';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: phoneController,
                    label: 'Phone Number',
                    icon: Icons.phone,
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter phone number';
                      }
                      if (value.length < 10) {
                        return 'Enter valid 10-digit number';
                      }
                      return null;
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Professional Information Card
              _buildSectionCard(
                title: 'Professional Details',
                icon: Icons.work_outline,
                children: [
                  _buildTextField(
                    controller: experienceController,
                    label: 'Experience (years)',
                    icon: Icons.timeline,
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter experience';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: specializationController,
                    label: 'Specialization',
                    icon: Icons.star_outline,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter specialization';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: bioController,
                    label: 'Bio / About Yourself',
                    icon: Icons.description,
                    maxLines: 3,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please tell us about yourself';
                      }
                      return null;
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Address Card
              _buildSectionCard(
                title: 'Address Details',
                icon: Icons.location_city,
                children: [
                  _buildTextField(
                    controller: addressController,
                    label: 'Address',
                    icon: Icons.home_outlined,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter address';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: cityController,
                    label: 'City',
                    icon: Icons.location_city,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter city';
                      }
                      return null;
                    },
                  ),
                  _buildTextField(
                    controller: pincodeController,
                    label: 'Pincode',
                    icon: Icons.pin_drop,
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter pincode';
                      }
                      if (value.length < 6) {
                        return 'Enter valid 6-digit pincode';
                      }
                      return null;
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Password Card
              _buildSectionCard(
                title: 'Security',
                icon: Icons.lock_outline,
                children: [
                  _buildPasswordField(
                    controller: passwordController,
                    label: 'Password',
                    obscure: _obscurePassword,
                    toggleObscure: () {
                      setState(() {
                        _obscurePassword = !_obscurePassword;
                      });
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter password';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildPasswordField(
                    controller: confirmPasswordController,
                    label: 'Confirm Password',
                    obscure: _obscureConfirmPassword,
                    toggleObscure: () {
                      setState(() {
                        _obscureConfirmPassword = !_obscureConfirmPassword;
                      });
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please confirm password';
                      }
                      if (value != passwordController.text) {
                        return 'Passwords do not match';
                      }
                      return null;
                    },
                  ),
                ],
              ),
              const SizedBox(height: 30),

              // Register Button
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _registerArtist,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: hennaBrown,
                    foregroundColor: Colors.white,
                    elevation: 5,
                    shadowColor: hennaDeep,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(color: hennaGold, width: 2),
                    ),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(
                    strokeWidth: 3,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  )
                      : const Text(
                    'Register as Artist',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // Helper method to build section cards
  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: hennaGold.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: hennaBrown, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: hennaDeep,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  // Helper method to build text fields
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    required String? Function(String?) validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        style: const TextStyle(color: hennaDeep),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: hennaBrown),
          prefixIcon: Icon(icon, color: hennaBrown, size: 20),
          filled: true,
          fillColor: hennaLight,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: hennaGold),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: hennaBrown, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: Colors.red),
          ),
        ),
        validator: validator,
      ),
    );
  }

  // Helper method to build password fields
  Widget _buildPasswordField({
    required TextEditingController controller,
    required String label,
    required bool obscure,
    required VoidCallback toggleObscure,
    required String? Function(String?) validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(color: hennaDeep),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: hennaBrown),
        prefixIcon: const Icon(Icons.lock_outline, color: hennaBrown, size: 20),
        suffixIcon: IconButton(
          icon: Icon(
            obscure ? Icons.visibility_off : Icons.visibility,
            color: hennaGold,
          ),
          onPressed: toggleObscure,
        ),
        filled: true,
        fillColor: hennaLight,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: hennaGold),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: hennaBrown, width: 2),
        ),
      ),
      validator: validator,
    );
  }

  // Image picker method
  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 75,
      );

      if (image != null) {
        setState(() {
          _profileImage = File(image.path);
        });
      }
    } catch (e) {
      print('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to pick image'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Registration method - sends data to Python backend
  Future<void> _registerArtist() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_profileImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please upload a profile image'),
          backgroundColor: hennaBrown,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Get server URL from SharedPreferences
      final sh = await SharedPreferences.getInstance();
      String baseUrl = sh.getString("url") ?? "http://your-server-ip"; // Replace with your actual server URL

      // Prepare the request
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/myapp/artist_register/'), // Update with your Python endpoint
      );

      // Add text fields
      request.fields['email'] = idController.text.trim();
      request.fields['first_name'] = fnameController.text.trim();
      request.fields['last_name'] = lnameController.text.trim();
      request.fields['phone'] = phoneController.text.trim();
      request.fields['experience_years'] = experienceController.text.trim();
      request.fields['specialization'] = specializationController.text.trim();
      request.fields['bio'] = bioController.text.trim();
      request.fields['address'] = addressController.text.trim();
      request.fields['city'] = cityController.text.trim();
      request.fields['pincode'] = pincodeController.text.trim();
      request.fields['password'] = passwordController.text.trim();

      // Add profile image
      if (_profileImage != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'profile_image',
            _profileImage!.path,
          ),
        );
      }

      // Send request
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var data = json.decode(responseData);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Success
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 10),
                Expanded(child: Text(data['message'] ?? 'Registration successful!')),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        );

        // Navigate back to login after successful registration
        Navigator.pop(context);
      } else {
        // Show error
        _showError(data['error'] ?? 'Registration failed');
      }
    } catch (e) {
      print('Registration error: $e');
      _showError('Network error. Please try again.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }
}