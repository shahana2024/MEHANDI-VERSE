import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mehndi_flutter/register.dart';
import 'package:mehndi_flutter/user_home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

import 'artist_home.dart';
import 'artist_register.dart';

// Import your actual registration pages (update these paths as needed)

void main() {
  runApp(const MehandiArtistApp());
}

class MehandiArtistApp extends StatelessWidget {
  const MehandiArtistApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MehandiVerse',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B4C39),
          primary: const Color(0xFF8B4C39),
          secondary: const Color(0xFFE8AA6B),
        ),
        fontFamily: 'Outfit',
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const MehandiLoginPage(),
    );
  }
}

class MehandiLoginPage extends StatefulWidget {
  const MehandiLoginPage({super.key});

  @override
  State<MehandiLoginPage> createState() => _MehandiLoginPageState();
}

class _MehandiLoginPageState extends State<MehandiLoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool _isLoading = false;
  bool _isPasswordVisible = false;



  // Mehandi-inspired color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaCream = Color(0xFFFFF8F2);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),

              // Mehandi Logo
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: hennaGold.withOpacity(0.5),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: CircleAvatar(
                  radius: 60,
                  backgroundColor: hennaBrown,
                  child: const Icon(
                    Icons.handshake_rounded,
                    size: 60,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // App Name with Gradient
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [hennaBrown, hennaDeep],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: const Text(
                  'MehandiVerse',
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: hennaGold, width: 1),
                ),
                child: const Text(
                  'Artist & User Portal',
                  style: TextStyle(
                    fontSize: 16,
                    color: hennaDeep,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // Decorative Motif
              Row(
                children: [
                  Expanded(child: Divider(color: hennaGold, thickness: 1.5)),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: hennaLight,
                      shape: BoxShape.circle,
                      border: Border.all(color: hennaBrown, width: 2),
                    ),
                    child: const Icon(Icons.spa, color: hennaBrown, size: 20),
                  ),
                  Expanded(child: Divider(color: hennaGold, thickness: 1.5)),
                ],
              ),
              const SizedBox(height: 30),

              // Login Card
              Card(
                elevation: 8,
                shadowColor: hennaBrown.withOpacity(0.4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                  side: BorderSide(color: hennaGold.withOpacity(0.5), width: 1.5),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    gradient: LinearGradient(
                      colors: [Colors.white, hennaCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(28.0),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          // Username Field
                          TextFormField(
                            controller: usernameController,
                            decoration: InputDecoration(
                              labelText: 'Username',
                              labelStyle: const TextStyle(color: hennaBrown),
                              prefixIcon: const Icon(Icons.person_outline, color: hennaBrown),
                              filled: true,
                              fillColor: hennaLight,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: hennaGold),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(color: hennaBrown, width: 2),
                              ),
                            ),
                            validator: (value) => value!.isEmpty
                                ? 'Please enter your username'
                                : null,
                          ),
                          const SizedBox(height: 20),

                          // Password Field
                      // Add this state variable at the top of your _MehandiLoginPageState class

                      TextFormField(
                      controller: passwordController,
                      obscureText: !_isPasswordVisible, // Toggle based on state
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: const TextStyle(color: hennaBrown),
                        prefixIcon: const Icon(Icons.lock_outline, color: hennaBrown),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
                            color: hennaBrown,
                          ),
                          onPressed: () {
                            setState(() {
                              _isPasswordVisible = !_isPasswordVisible;
                            });
                          },
                        ),
                        filled: true,
                        fillColor: hennaLight,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(color: hennaGold),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(color: hennaGold.withOpacity(0.5)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: const BorderSide(color: hennaBrown, width: 2),
                        ),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) return 'Enter your password';
                        if (value.length < 6) {
                          return 'Password must be at least 6 characters';
                        }
                        return null;
                      },
                    ),
                          const SizedBox(height: 30),

                          // Login Button
                          SizedBox(
                            width: double.infinity,
                            height: 55,
                            child: ElevatedButton(
                              onPressed: _isLoading ? null : _handleLogin,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: hennaBrown,
                                foregroundColor: Colors.white,
                                elevation: 5,
                                shadowColor: hennaDeep,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                  side: BorderSide(color: hennaGold, width: 2),
                                ),
                              ),
                              child: _isLoading
                                  ? const CircularProgressIndicator(
                                strokeWidth: 3,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              )
                                  : const Text(
                                'Login to MehandiVerse',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 25),

              // Register Section with Two Buttons
              Container(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                decoration: BoxDecoration(
                  color: hennaCream,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: hennaGold.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: hennaBrown.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Text(
                      'New to MehandiVerse?',
                      style: TextStyle(
                        fontSize: 16,
                        color: hennaDeep,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Two Register Buttons Side by Side
                    Row(
                      children: [
                        // Artist Register Button
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const ArtistRegisterPage(), // Create this page
                                ),
                              );
                            },
                            icon: const Icon(Icons.brush, color: hennaBrown),
                            label: const Text(
                              'Artist',
                              style: TextStyle(color: hennaDeep),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: hennaLight,
                              foregroundColor: hennaDeep,
                              elevation: 2,
                              side: BorderSide(color: hennaGold, width: 1.5),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),

                        // User Register Button
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const UserRegisterPage(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.person_add, color: Colors.white),
                            label: const Text(
                              'User',
                              style: TextStyle(color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: hennaBrown,
                              foregroundColor: Colors.white,
                              elevation: 4,
                              shadowColor: hennaDeep,
                              side: BorderSide(color: hennaGold, width: 1.5),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    // Optional: Forgot password link
                    TextButton(
                      onPressed: () {
                        // Add forgot password functionality
                      },
                      child: const Text(
                        'Forgot password?',
                        style: TextStyle(color: hennaGold),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              // Footer with Mehandi Motif
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.circle, color: hennaGold, size: 8),
                      const SizedBox(width: 8),
                      Icon(Icons.circle, color: hennaBrown, size: 12),
                      const SizedBox(width: 8),
                      Icon(Icons.circle, color: hennaGold, size: 8),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'connect with henna artists worldwide',
                    style: TextStyle(
                      color: hennaDeep,
                      fontSize: 13,
                    ),
                  ),
                  const Text(
                    '© 2026 mehandiVerse',
                    style: TextStyle(
                      color: hennaGold,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleLogin() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Get user location
      bool serviceEnabled;
      LocationPermission permission;

      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showSnackBar('Please enable location services');
        setState(() => _isLoading = false);
        return;
      }

      permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showSnackBar('Location permission denied');
          setState(() => _isLoading = false);
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _showSnackBar('Location permission permanently denied');
        setState(() => _isLoading = false);
        return;
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      double latitude = position.latitude;
      double longitude = position.longitude;

      print("📍 Current location: $latitude, $longitude");

      // Proceed with login
      final sh = await SharedPreferences.getInstance();
      String uname = usernameController.text.trim();
      String pwd = passwordController.text.trim();
      String url = sh.getString("url") ?? "";

      final res = await http.post(
        Uri.parse("$url/myapp/userlogin"),
        body: {
          'username1': uname,
          'password': pwd,
          'latitude': latitude.toString(),
          'longitude': longitude.toString(),
        },
      );

      final data = json.decode(res.body);
      print("Response: $data");

      String type = data['group'].toString();
      String lid = data['login_id'].toString();
      String address = data['address'].toString();
      String name = data['name'].toString();


      sh.setString("lid", lid);
      sh.setString("name", name);
      sh.setString("address", address);
      print("dddddddddddddddd$type");
      if (type == "artist") {

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ArtistHomePage()),
        );
      }
        if (type == "User") {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const UserHomePage()),
          );
      } else {
        _showError();
      }
    } catch (e) {
      print("Login error: $e");
      _showError();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: hennaBrown,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  void _showError() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invalid username or password'),
        backgroundColor: Colors.red,
      ),
    );
  }
}