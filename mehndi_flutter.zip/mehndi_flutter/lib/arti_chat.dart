// arti_chat_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';

class Arti_ChatPage extends StatefulWidget {
  final String artistId;
  final String artistName;
  const Arti_ChatPage({Key? key, required this.artistId, required this.artistName}) : super(key: key);

  @override
  State<Arti_ChatPage> createState() => _Arti_ChatPageState();
}

class _Arti_ChatPageState extends State<Arti_ChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<Map<String, dynamic>> messages = [];
  String baseUrl = "";
  String senderId = "";
  bool isLoading = true;
  bool isSending = false;

  // Image picker
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();
  bool _isImageSelected = false;

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrlAndMessages();
  }

  Future<void> _loadBaseUrlAndMessages() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    baseUrl = prefs.getString("url") ?? "";
    senderId = prefs.getString("lid") ?? "";
    await _fetchMessages();
  }

  Future<void> _fetchMessages() async {
    try {
      final response = await http.get(Uri.parse(
        '$baseUrl/myapp/arti_view_chat/$senderId/${widget.artistId}',
      ));
      final data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          messages = List<Map<String, dynamic>>.from(data['data']);
          isLoading = false;
        });
        _scrollToBottom();
      }
    } catch (e) {
      print("Error fetching chat: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  // Pick image from gallery
  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _selectedImage = File(image.path);
          _isImageSelected = true;
        });
      }
    } catch (e) {
      _showSnackBar('Failed to pick image: $e', Colors.red);
    }
  }

  // Clear selected image
  void _clearSelectedImage() {
    setState(() {
      _selectedImage = null;
      _isImageSelected = false;
    });
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();

    if ((text.isEmpty && _selectedImage == null) || isSending) return;

    setState(() {
      isSending = true;
    });

    try {
      if (_selectedImage != null) {
        // Send image with optional text
        await _sendImageMessage(text);
      } else {
        // Send text only
        await _sendTextMessage(text);
      }
    } catch (e) {
      print("Error sending message: $e");
      _showSnackBar('Failed to send message', Colors.red);
    } finally {
      setState(() {
        isSending = false;
        _messageController.clear();
        _selectedImage = null;
        _isImageSelected = false;
      });
    }
  }

  Future<void> _sendTextMessage(String text) async {
    final response = await http.post(
      Uri.parse('$baseUrl/myapp/arti_send_chat'),
      body: {
        'chat': text,
        'sender_id': senderId,
        'receiver_id': widget.artistId,
        'message_type': 'text',
      },
    );

    final data = json.decode(response.body);
    if (data['status'] == 'success') {
      await _fetchMessages();
    } else {
      throw Exception('Failed to send message');
    }
  }

  Future<void> _sendImageMessage(String text) async {
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/myapp/arti_send_chat_image/'),
    );

    request.fields['sender_id'] = senderId;
    request.fields['receiver_id'] = widget.artistId;
    request.fields['chat'] = text;
    request.fields['message_type'] = 'image';

    request.files.add(
      await http.MultipartFile.fromPath(
        'chat_image',
        _selectedImage!.path,
      ),
    );

    var response = await request.send();
    var responseData = await response.stream.bytesToString();
    var data = json.decode(responseData);

    if (response.statusCode == 200 && data['status'] == 'success') {
      await _fetchMessages();
    } else {
      throw Exception(data['message'] ?? 'Failed to send image');
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  String _formatTime(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return DateFormat('HH:mm').format(date);
    } catch (e) {
      return '';
    }
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      if (date.year == now.year && date.month == now.month && date.day == now.day) {
        return 'Today';
      } else if (date.year == now.year && date.month == now.month && date.day == now.day - 1) {
        return 'Yesterday';
      } else {
        return DateFormat('MMM dd, yyyy').format(date);
      }
    } catch (e) {
      return '';
    }
  }

  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = this.baseUrl.endsWith('/') ? this.baseUrl.substring(0, this.baseUrl.length - 1) : this.baseUrl;

    return '$baseUrl/$cleanPath';
  }

  void _showImageDialog(String imageUrl) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                imageUrl,
                fit: BoxFit.contain,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Container(
                    height: 300,
                    color: hennaLight,
                    child: Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                      ),
                    ),
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    height: 300,
                    color: hennaLight,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.broken_image, color: hennaGold, size: 50),
                          const Text('Failed to load image'),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                decoration: BoxDecoration(
                  color: hennaBrown,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.info, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, int index) {
    bool isMine = message['sender_id'] == int.tryParse(senderId);
    String messageTime = _formatTime(message['date'] ?? '');
    String messageType = message['message_type'] ?? 'text';
    String? imageUrl = message['image_url'];

    bool showDate = false;
    if (index == 0) {
      showDate = true;
    } else {
      final currentDate = message['date'] ?? '';
      final previousDate = messages[index - 1]['date'] ?? '';
      if (_formatDate(currentDate) != _formatDate(previousDate)) {
        showDate = true;
      }
    }

    return Column(
      children: [
        if (showDate)
          Container(
            margin: const EdgeInsets.symmetric(vertical: 16),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [hennaGold.withOpacity(0.2), hennaBrown.withOpacity(0.2)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: hennaGold.withOpacity(0.3)),
            ),
            child: Text(
              _formatDate(message['date'] ?? ''),
              style: TextStyle(
                fontSize: 12,
                color: hennaDeep,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            mainAxisAlignment: isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isMine) ...[
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: hennaBrown.withOpacity(0.2),
                        blurRadius: 4,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 18,
                    backgroundColor: hennaCream,
                    child: Icon(
                      Iconsax.brush_1,
                      size: 16,
                      color: hennaBrown,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 2),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: isMine
                        ? LinearGradient(
                      colors: [hennaBrown, hennaDeep],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                        : LinearGradient(
                      colors: [hennaCream, hennaLight],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(20),
                      topRight: const Radius.circular(20),
                      bottomLeft: isMine ? const Radius.circular(20) : const Radius.circular(4),
                      bottomRight: isMine ? const Radius.circular(4) : const Radius.circular(20),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: hennaBrown.withOpacity(0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                    border: Border.all(
                      color: isMine ? hennaGold.withOpacity(0.3) : hennaGold.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Image message
                      if (messageType == 'image' && imageUrl != null)
                        GestureDetector(
                          onTap: () => _showImageDialog(_getFullImageUrl(imageUrl)),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: hennaGold.withOpacity(0.3)),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                _getFullImageUrl(imageUrl),
                                height: 150,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                loadingBuilder: (context, child, loadingProgress) {
                                  if (loadingProgress == null) return child;
                                  return Container(
                                    height: 150,
                                    color: hennaLight,
                                    child: Center(
                                      child: CircularProgressIndicator(
                                        valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                                      ),
                                    ),
                                  );
                                },
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    height: 150,
                                    color: hennaLight,
                                    child: Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.broken_image, color: hennaGold, size: 30),
                                          const Text('Failed to load'),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),

                      // Text message
                      if (message['message'] != null && message['message'].toString().isNotEmpty)
                        Text(
                          message['message'] ?? "",
                          style: TextStyle(
                            fontSize: 15,
                            color: isMine ? Colors.white : hennaDeep,
                            height: 1.3,
                          ),
                        ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            messageTime,
                            style: TextStyle(
                              fontSize: 10,
                              color: isMine ? hennaGold.withOpacity(0.8) : hennaBrown.withOpacity(0.6),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          if (isMine) ...[
                            const SizedBox(width: 4),
                            Icon(
                              Iconsax.tick_circle,
                              size: 12,
                              color: hennaGold.withOpacity(0.8),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              if (isMine) ...[
                const SizedBox(width: 8),
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: hennaGold, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: hennaBrown.withOpacity(0.2),
                        blurRadius: 4,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 18,
                    backgroundColor: hennaCream,
                    child: Icon(
                      Iconsax.user,
                      size: 16,
                      color: hennaBrown,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Image preview if selected
          if (_isImageSelected && _selectedImage != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: hennaLight,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: hennaGold.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(
                      _selectedImage!,
                      height: 50,
                      width: 50,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Image selected',
                      style: TextStyle(
                        color: hennaDeep,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close, color: hennaBrown),
                    onPressed: _clearSelectedImage,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),

          // Input row
          Row(
            children: [
              // Image picker button
              Container(
                margin: const EdgeInsets.only(right: 4),
                decoration: BoxDecoration(
                  color: hennaGold.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: IconButton(
                  icon: Icon(
                    Iconsax.gallery,
                    color: hennaBrown,
                    size: 22,
                  ),
                  onPressed: _pickImage,
                ),
              ),

              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: hennaLight,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: hennaGold.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const SizedBox(width: 16),
                      Expanded(
                        child: TextField(
                          controller: _messageController,
                          decoration: InputDecoration(
                            hintText: _isImageSelected ? "Add caption..." : "Type your message...",
                            hintStyle: TextStyle(
                              color: hennaBrown.withOpacity(0.5),
                              fontSize: 14,
                            ),
                            border: InputBorder.none,
                          ),
                          maxLines: null,
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _sendMessage(),
                          style: TextStyle(color: hennaDeep),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),

              // Send button
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [hennaBrown, hennaDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: hennaDeep.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _sendMessage,
                    borderRadius: BorderRadius.circular(30),
                    child: Container(
                      width: 50,
                      height: 50,
                      child: Center(
                        child: isSending
                            ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(hennaGold),
                          ),
                        )
                            : Icon(Iconsax.send_1, color: hennaGold, size: 22),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [hennaLight, hennaCream],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(
                  Iconsax.message,
                  size: 50,
                  color: hennaGold,
                ),
                Positioned(
                  bottom: 30,
                  right: 30,
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: hennaBrown,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
                Positioned(
                  top: 30,
                  left: 30,
                  child: Container(
                    width: 15,
                    height: 15,
                    decoration: BoxDecoration(
                      color: hennaRose,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (index) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 2),
                child: Icon(
                  index.isEven ? Icons.circle : Icons.favorite,
                  color: hennaGold.withOpacity(0.3),
                  size: 8,
                ),
              );
            }),
          ),
          const SizedBox(height: 16),
          Text(
            "No messages yet",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              "Start a conversation with ${widget.artistName}",
              style: TextStyle(
                fontSize: 14,
                color: hennaBrown,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 30),
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Iconsax.brush_1,
              size: 30,
              color: hennaBrown.withOpacity(0.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: hennaGold, width: 2),
            ),
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            "Loading messages...",
            style: TextStyle(
              fontSize: 16,
              color: hennaDeep,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Iconsax.brush_2, color: hennaGold.withOpacity(0.5), size: 16),
              const SizedBox(width: 4),
              Icon(Iconsax.brush_3, color: hennaGold.withOpacity(0.5), size: 16),
              const SizedBox(width: 4),
              Icon(Iconsax.brush_4, color: hennaGold.withOpacity(0.5), size: 16),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderDecoration() {
    return Container(
      height: 60,
      child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: hennaGold.withOpacity(0.2),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: hennaRose.withOpacity(0.1),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        leading: Container(
          margin: const EdgeInsets.only(left: 8),
          decoration: BoxDecoration(
            color: hennaGold.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: hennaGold, width: 1),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: hennaGold, width: 2),
                gradient: LinearGradient(
                  colors: [hennaCream, hennaLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Icon(
                Iconsax.brush_1,
                color: hennaBrown,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.artistName,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: hennaGold,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        "Online",
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
      ),
      body: Column(
        children: [
          _buildHeaderDecoration(),
          Expanded(
            child: isLoading
                ? _buildLoadingState()
                : messages.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: messages.length,
              itemBuilder: (context, index) =>
                  _buildMessageBubble(messages[index], index),
            ),
          ),
          _buildInputArea(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}