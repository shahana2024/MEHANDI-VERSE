// profile_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:iconsax/iconsax.dart';

// Profile Model Class
class UserProfile {
  final int? id;
  final String fname;
  final String lname;
  final String phone;
  final String address;
  final String pincode;
  final String city;
  final String gender;

  UserProfile({
    this.id,
    required this.fname,
    required this.lname,
    required this.phone,
    required this.address,
    required this.pincode,
    required this.city,
    required this.gender,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'],
      fname: json['fname'] ?? '',
      lname: json['lname'] ?? '',
      phone: json['phone'] ?? '',
      address: json['address'] ?? '',
      pincode: json['pincode'] ?? '',
      city: json['city'] ?? '',
      gender: json['gender'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'fname': fname,
      'lname': lname,
      'phone': phone,
      'address': address,
      'pincode': pincode,
      'city': city,
      'gender': gender,
    };
  }

  String get fullName => '$fname $lname';
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  UserProfile? _profile;
  bool _isLoading = true;
  bool _isEditing = false;
  String? _errorMessage;
  String _baseUrl = '';

  // Form controllers
  final _formKey = GlobalKey<FormState>();
  final _fnameController = TextEditingController();
  final _lnameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _pincodeController = TextEditingController();
  final _cityController = TextEditingController();
  String? _selectedGender;
  final List<String> _genderOptions = ['Male', 'Female', 'Other'];

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrl();
  }

  @override
  void dispose() {
    _fnameController.dispose();
    _lnameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _pincodeController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  // Load base URL from SharedPreferences
  Future<void> _loadBaseUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchProfile();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Fetch profile data
  Future<void> _fetchProfile() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('lid');

      if (userId == null) {
        setState(() {
          _errorMessage = 'User not logged in';
          _isLoading = false;
        });
        return;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_profile/'),
        body: {'lid': userId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _profile = UserProfile.fromJson(data['profile']);
          });
          _populateControllers();
        } else {
          throw Exception(data['message'] ?? 'Failed to load profile');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Populate controllers with profile data
  void _populateControllers() {
    if (_profile != null) {
      _fnameController.text = _profile!.fname;
      _lnameController.text = _profile!.lname;
      _phoneController.text = _profile!.phone;
      _addressController.text = _profile!.address;
      _pincodeController.text = _profile!.pincode;
      _cityController.text = _profile!.city;

      // Fix gender value - ensure it matches one of the options
      String gender = _profile!.gender.trim().toLowerCase();
      if (gender == 'male') {
        _selectedGender = 'Male';
      } else if (gender == 'female') {
        _selectedGender = 'Female';
      } else if (gender == 'other') {
        _selectedGender = 'Other';
      } else {
        _selectedGender = 'Male'; // Default fallback
      }
    }
  }

  // Update profile
  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedGender == null) {
      _showSnackBar('Please select gender', Colors.orange);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('lid');

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/user_update_profile/'),
        body: {
          'lid': userId!,
          'fname': _fnameController.text,
          'lname': _lnameController.text,
          'phone': _phoneController.text,
          'address': _addressController.text,
          'pincode': _pincodeController.text,
          'city': _cityController.text,
          'gender': _selectedGender!,
        },
      );

      var data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('Profile updated successfully', Colors.green);
        setState(() {
          _isEditing = false;
        });
        await _fetchProfile(); // Refresh profile data
      } else {
        throw Exception(data['message'] ?? 'Failed to update profile');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // Cancel editing
  void _cancelEditing() {
    setState(() {
      _isEditing = false;
    });
    _populateControllers(); // Reset form values
  }

  // Show snackbar
  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              color == Colors.green ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        title: Text(
          _isEditing ? 'Edit Profile' : 'My Profile',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: _buildAppBarActions(),
      ),
      body: _isLoading
          ? _buildLoadingIndicator()
          : _errorMessage != null
          ? _buildErrorWidget()
          : _profile == null
          ? _buildEmptyWidget()
          : _isEditing
          ? _buildEditForm()
          : _buildProfileView(),
    );
  }

  // App bar actions
  List<Widget> _buildAppBarActions() {
    if (_isLoading) return [];

    if (_isEditing) {
      return [
        TextButton(
          onPressed: _cancelEditing,
          child: const Text(
            'Cancel',
            style: TextStyle(color: Colors.white),
          ),
        ),
        TextButton(
          onPressed: _updateProfile,
          child: const Text(
            'Save',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ];
    } else {
      return [
        IconButton(
          icon: const Icon(Icons.edit),
          onPressed: () {
            setState(() => _isEditing = true);
          },
        ),
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _fetchProfile,
        ),
      ];
    }
  }

  // Loading indicator
  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
          ),
          const SizedBox(height: 20),
          Text(
            'Loading profile...',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Error widget
  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Error',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadBaseUrl,
              style: ElevatedButton.styleFrom(
                backgroundColor: hennaBrown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  // Empty widget
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.person_outline, size: 100, color: hennaGold),
          const SizedBox(height: 20),
          const Text(
            'No Profile Found',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: hennaDeep,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Create your profile to get started',
            style: TextStyle(color: hennaBrown),
          ),
        ],
      ),
    );
  }

  // Profile View Mode
  Widget _buildProfileView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Personal Information Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: hennaCream,
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: hennaBrown.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section Title
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: hennaGold.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(Iconsax.user, color: hennaBrown, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Personal Information',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: hennaDeep,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Full Name
                _buildInfoRow(
                  icon: Iconsax.user,
                  label: 'Full Name',
                  value: _profile!.fullName,
                ),
                const Divider(height: 24),

                // Phone
                _buildInfoRow(
                  icon: Iconsax.call,
                  label: 'Phone Number',
                  value: _profile!.phone,
                ),
                const Divider(height: 24,),

                // Gender
                _buildInfoRow(
                  icon: _profile!.gender.toLowerCase() == 'male'
                      ? Iconsax.man
                      : _profile!.gender.toLowerCase() == 'female'
                      ? Iconsax.woman
                      : Iconsax.user,
                  label: 'Gender',
                  value: _profile!.gender,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Address Information Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: hennaCream,
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: hennaBrown.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section Title
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: hennaGold.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(Iconsax.location, color: hennaBrown, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Address Information',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: hennaDeep,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Address
                _buildInfoRow(
                  icon: Iconsax.home,
                  label: 'Address',
                  value: _profile!.address,
                  isMultiline: true,
                ),
                const Divider(height: 24),

                // City
                _buildInfoRow(
                  icon: Iconsax.building,
                  label: 'City',
                  value: _profile!.city,
                ),
                const Divider(height: 24, ),

                // Pincode
                _buildInfoRow(
                  icon: Iconsax.code,
                  label: 'Pincode',
                  value: _profile!.pincode,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Edit Button
          Container(
            width: double.infinity,
            height: 55,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [hennaBrown, hennaDeep],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: hennaDeep.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: () {
                setState(() => _isEditing = true);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Iconsax.edit, size: 20),
                  SizedBox(width: 10),
                  Text(
                    'Edit Profile',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // Info row helper for view mode
  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    bool isMultiline = false,
  }) {
    return Row(
      crossAxisAlignment: isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
      children: [
        Icon(icon, size: 20, color: hennaGold),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: hennaBrown.withOpacity(0.7),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value.isEmpty ? 'Not provided' : value,
                style: TextStyle(
                  fontSize: 16,
                  color: value.isEmpty ? hennaBrown.withOpacity(0.5) : hennaDeep,
                  fontStyle: value.isEmpty ? FontStyle.italic : FontStyle.normal,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Edit Form Mode
  Widget _buildEditForm() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            // Personal Information Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: hennaCream,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: hennaBrown.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: hennaGold.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(Iconsax.user, color: hennaBrown, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'Personal Information',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: hennaDeep,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // First Name
                  _buildEditField(
                    controller: _fnameController,
                    label: 'First Name',
                    icon: Iconsax.user,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'First name is required';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Last Name
                  _buildEditField(
                    controller: _lnameController,
                    label: 'Last Name',
                    icon: Iconsax.user,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'Last name is required';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Phone
                  _buildEditField(
                    controller: _phoneController,
                    label: 'Phone Number',
                    icon: Iconsax.call,
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'Phone number is required';
                      if (value!.length < 10) return 'Enter a valid 10-digit phone number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Gender Dropdown
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: hennaGold.withOpacity(0.3)),
                      color: hennaLight,
                    ),
                    child: DropdownButtonFormField<String>(
                      value: _selectedGender,
                      hint: const Text('Select Gender'),
                      decoration: InputDecoration(
                        labelText: 'Gender',
                        labelStyle: TextStyle(color: hennaBrown),
                        prefixIcon: Icon(
                          _selectedGender == 'Male'
                              ? Iconsax.man
                              : _selectedGender == 'Female'
                              ? Iconsax.woman
                              : Iconsax.user,
                          color: hennaBrown,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ),
                      items: _genderOptions.map((gender) {
                        return DropdownMenuItem(
                          value: gender,
                          child: Text(
                            gender,
                            style: const TextStyle(color: hennaDeep),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedGender = value;
                        });
                      },
                      dropdownColor: hennaCream,
                      icon: Icon(Iconsax.arrow_down_1, color: hennaBrown),
                      style: const TextStyle(color: hennaDeep),
                      validator: (value) {
                        if (value == null) {
                          return 'Please select gender';
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Address Information Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: hennaCream,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: hennaBrown.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: hennaGold.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(Iconsax.location, color: hennaBrown, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'Address Information',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: hennaDeep,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Address
                  _buildEditField(
                    controller: _addressController,
                    label: 'Address',
                    icon: Iconsax.home,
                    maxLines: 3,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'Address is required';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // City
                  _buildEditField(
                    controller: _cityController,
                    label: 'City',
                    icon: Iconsax.building,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'City is required';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Pincode
                  _buildEditField(
                    controller: _pincodeController,
                    label: 'Pincode',
                    icon: Iconsax.code,
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value?.isEmpty == true) return 'Pincode is required';
                      if (value!.length != 6) return 'Enter a valid 6-digit pincode';
                      return null;
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _cancelEditing,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: hennaBrown,
                      side: BorderSide(color: hennaBrown),
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text('Cancel'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [hennaBrown, hennaDeep],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ElevatedButton(
                      onPressed: _updateProfile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        foregroundColor: Colors.white,
                        shadowColor: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: const Text('Save Changes'),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // Edit field builder
  Widget _buildEditField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    required String? Function(String?) validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
        color: hennaLight,
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        style: const TextStyle(color: hennaDeep),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: hennaBrown),
          prefixIcon: Icon(icon, color: hennaBrown),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        validator: validator,
      ),
    );
  }
}