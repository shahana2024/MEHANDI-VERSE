import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ViewDesignsPage extends StatefulWidget {
  const ViewDesignsPage({super.key});

  @override
  State<ViewDesignsPage> createState() => _ViewDesignsPageState();
}

class _ViewDesignsPageState extends State<ViewDesignsPage> {
  List<Map<String, dynamic>> _designs = [];
  bool _isLoading = true;
  String? _errorMessage;
  String _baseUrl = '';

  // For edit functionality
  Map<String, dynamic>? _selectedDesign;
  bool _isEditing = false;

  // Edit form controllers
  final TextEditingCollection _editControllers = TextEditingCollection();

  // Image picker for edit
  File? _newImage;
  final ImagePicker _picker = ImagePicker();

  // Mehandi color palette
  static const Color hennaBrown = Color(0xFF8B4C39);
  static const Color hennaGold = Color(0xFFE8AA6B);
  static const Color hennaDeep = Color(0xFF5E2E1C);
  static const Color hennaLight = Color(0xFFFCF3EC);
  static const Color hennaCream = Color(0xFFFFF8F2);
  static const Color hennaRose = Color(0xFFD68F6B);
  static const Color hennaSage = Color(0xFF9FB7A5);

  @override
  void initState() {
    super.initState();
    _loadBaseUrlAndFetchDesigns();
  }

  @override
  void dispose() {
    _editControllers.dispose();
    super.dispose();
  }

  Future<void> _loadBaseUrlAndFetchDesigns() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _baseUrl = prefs.getString('url') ?? '';
      });

      if (_baseUrl.isEmpty) {
        setState(() {
          _errorMessage = 'Server URL not configured';
          _isLoading = false;
        });
        return;
      }

      await _fetchDesigns();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  String _getFullImageUrl(String? imagePath) {
    if (imagePath == null || imagePath.isEmpty) return '';
    if (imagePath.startsWith('http')) return imagePath;

    String cleanPath = imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;
    String baseUrl = _baseUrl.endsWith('/') ? _baseUrl.substring(0, _baseUrl.length - 1) : _baseUrl;

    return '$baseUrl/$cleanPath';
  }

  Future<void> _fetchDesigns() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      String? artistId = prefs.getString('lid');

      if (artistId == null) {
        throw Exception('Please login first');
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/view_designs/'),
        body: {'lid': artistId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            _designs = List<Map<String, dynamic>>.from(data['designs']);
          });
        } else {
          throw Exception(data['message'] ?? 'Failed to load designs');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _deleteDesign(String designId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Design'),
        content: const Text('Are you sure you want to delete this design?'),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        backgroundColor: hennaLight,
        titleTextStyle: const TextStyle(
          color: hennaDeep,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: const TextStyle(color: hennaBrown),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'Cancel',
              style: TextStyle(color: hennaGold),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/myapp/delete_design/'),
        body: {'design_id': designId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          _showSnackBar('Design deleted successfully', Colors.green);
          _fetchDesigns();
        } else {
          throw Exception(data['message'] ?? 'Delete failed');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _openEditDialog(Map<String, dynamic> design) {
    setState(() {
      _selectedDesign = design;
      _isEditing = true;
      _newImage = null;
    });

    _editControllers.designType.text = design['design_type'] ?? '';
    _editControllers.handSize.text = design['hand_size'] ?? '';
    _editControllers.coverage.text = design['coverage'] ?? '';
    _editControllers.price.text = design['price']?.toString() ?? '';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildEditBottomSheet(),
    );
  }

  Widget _buildEditBottomSheet() {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: BoxDecoration(
        color: hennaLight,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
        border: Border.all(color: hennaGold, width: 2),
        boxShadow: [
          BoxShadow(
            color: hennaDeep.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 60,
            height: 6,
            decoration: BoxDecoration(
              color: hennaGold,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 16),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.brush, color: hennaBrown, size: 24),
              const SizedBox(width: 8),
              const Text(
                'Edit Design',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: hennaDeep,
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.brush, color: hennaBrown, size: 24),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            width: 100,
            height: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [hennaGold, hennaBrown],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 20),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _editControllers.formKey,
                child: Column(
                  children: [
                    if (_selectedDesign != null)
                      Container(
                        height: 180,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: hennaGold, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: hennaDeep.withOpacity(0.2),
                              blurRadius: 15,
                              spreadRadius: 2,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(27),
                          child: _buildImagePreview(),
                        ),
                      ),
                    const SizedBox(height: 16),

                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [hennaBrown, hennaRose],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: hennaDeep.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: ElevatedButton.icon(
                        onPressed: _pickNewImage,
                        icon: const Icon(Icons.camera_alt, color: Colors.white),
                        label: const Text(
                          'Change Image',
                          style: TextStyle(color: Colors.white),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          foregroundColor: Colors.white,
                          shadowColor: Colors.transparent,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 30,
                            vertical: 15,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 25),

                    _buildAttractiveTextField(
                      controller: _editControllers.designType,
                      label: 'Design Type',
                      icon: Icons.category,
                      validator: (value) => value?.isEmpty == true ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    _buildAttractiveTextField(
                      controller: _editControllers.handSize,
                      label: 'Hand Size',
                      icon: Icons.back_hand,
                      validator: (value) => value?.isEmpty == true ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    _buildAttractiveTextField(
                      controller: _editControllers.coverage,
                      label: 'Coverage',
                      icon: Icons.grid_view,
                      validator: (value) => value?.isEmpty == true ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    _buildAttractiveTextField(
                      controller: _editControllers.price,
                      label: 'Price (₹)',
                      icon: Icons.currency_rupee,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value?.isEmpty == true) return 'Required';
                        if (double.tryParse(value!) == null) return 'Invalid price';
                        return null;
                      },
                    ),
                    const SizedBox(height: 30),

                    Container(
                      width: double.infinity,
                      height: 55,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [hennaBrown, hennaDeep],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: hennaDeep.withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: _updateDesign,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          foregroundColor: Colors.white,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          'Update Design',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImagePreview() {
    if (_newImage != null) {
      return Image.file(
        _newImage!,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
      );
    } else if (_selectedDesign != null && _selectedDesign!['image_url'] != null) {
      String imageUrl = _getFullImageUrl(_selectedDesign!['image_url']);

      return Image.network(
        imageUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            color: hennaCream,
            child: Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
              ),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          print('Error loading image: $error');
          return Container(
            color: hennaCream,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image, size: 40, color: hennaGold),
                const Text('Failed to load'),
              ],
            ),
          );
        },
      );
    } else {
      return Container(
        color: hennaCream,
        child: const Center(
          child: Icon(Icons.image, size: 40, color: hennaGold),
        ),
      );
    }
  }

  Widget _buildAttractiveTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    required String? Function(String?) validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: hennaBrown.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: hennaDeep, fontSize: 16),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: hennaBrown, fontWeight: FontWeight.w500),
          prefixIcon: Icon(icon, color: hennaBrown, size: 22),
          filled: true,
          fillColor: hennaCream,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: BorderSide(color: hennaGold, width: 1.5),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: BorderSide(color: hennaGold.withOpacity(0.5), width: 1.5),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: hennaBrown, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: Colors.red, width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        ),
        validator: validator,
      ),
    );
  }

  Future<void> _pickNewImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _newImage = File(image.path);
        });
      }
    } catch (e) {
      _showSnackBar('Failed to pick image', Colors.red);
    }
  }

  Future<void> _updateDesign() async {
    if (!_editControllers.formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });
    Navigator.pop(context);

    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$_baseUrl/myapp/update_design/'),
      );

      request.fields['design_id'] = _selectedDesign!['id'].toString();
      request.fields['design_type'] = _editControllers.designType.text;
      request.fields['hand_size'] = _editControllers.handSize.text;
      request.fields['coverage'] = _editControllers.coverage.text;
      request.fields['price'] = _editControllers.price.text;

      if (_newImage != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'design_image',
            _newImage!.path,
          ),
        );
      }

      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var data = json.decode(responseData);

      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('Design updated successfully', Colors.green);
        _fetchDesigns();
      } else {
        throw Exception(data['message'] ?? 'Update failed');
      }
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    } finally {
      setState(() {
        _isLoading = false;
        _isEditing = false;
        _selectedDesign = null;
      });
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              color == Colors.green ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: hennaLight,
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.brush, color: Colors.white, size: 24),
            const SizedBox(width: 8),
            const Text(
              'My Designs',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
            ),
          ],
        ),
        backgroundColor: hennaBrown,
        foregroundColor: Colors.white,
        elevation: 8,
        shadowColor: hennaDeep,
        centerTitle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
              color: hennaGold.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: _fetchDesigns,
              tooltip: 'Refresh',
            ),
          ),
        ],
      ),
      body: _isLoading
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
              strokeWidth: 4,
            ),
            const SizedBox(height: 20),
            Text(
              'Loading your designs...',
              style: TextStyle(color: hennaDeep, fontSize: 16),
            ),
          ],
        ),
      )
          : _errorMessage != null
          ? _buildErrorWidget()
          : _designs.isEmpty
          ? _buildEmptyWidget()
          : _buildDesignsList(), // Changed from _buildDesignsGrid to _buildDesignsList
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(30),
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          color: hennaCream,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: hennaGold, width: 2),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.2),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 80, color: hennaGold),
            const SizedBox(height: 20),
            Text(
              'Oops!',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _errorMessage!,
              style: const TextStyle(color: hennaBrown),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 25),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [hennaBrown, hennaGold],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(30),
              ),
              child: ElevatedButton(
                onPressed: _fetchDesigns,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text(
                  'Try Again',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(30),
        padding: const EdgeInsets.all(40),
        decoration: BoxDecoration(
          color: hennaCream,
          borderRadius: BorderRadius.circular(60),
          border: Border.all(color: hennaGold, width: 2),
          boxShadow: [
            BoxShadow(
              color: hennaBrown.withOpacity(0.2),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: hennaLight,
                shape: BoxShape.circle,
                border: Border.all(color: hennaGold, width: 3),
              ),
              child: Icon(Icons.brush, size: 60, color: hennaGold),
            ),
            const SizedBox(height: 25),
            const Text(
              'No Designs Yet',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: hennaDeep,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Upload your first mehandi design\nand showcase your art',
              style: TextStyle(color: hennaBrown, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 25),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [hennaGold, hennaBrown],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(30),
              ),
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.add, color: Colors.white),
                label: const Text(
                  'Add New Design',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // New method to build list view instead of grid
  Widget _buildDesignsList() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [hennaLight, hennaCream],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _designs.length,
        itemBuilder: (context, index) {
          final design = _designs[index];
          return _buildAttractiveDesignCard(design);
        },
      ),
    );
  }

  // Updated card design with proper layout
  Widget _buildAttractiveDesignCard(Map<String, dynamic> design) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
            color: hennaDeep.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 0,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
          side: BorderSide(color: hennaGold.withOpacity(0.5), width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image Section - Top
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(25),
              ),
              child: Stack(
                children: [
                  Container(
                    height: 200,
                    width: double.infinity,
                    color: hennaCream,
                    child: design['image_url'] != null
                        ? Image.network(
                      _getFullImageUrl(design['image_url']),
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(hennaBrown),
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.broken_image, size: 50, color: hennaGold),
                              const Text('Failed to load image'),
                            ],
                          ),
                        );
                      },
                    )
                        : Center(
                      child: Icon(Icons.image, size: 50, color: hennaGold),
                    ),
                  ),
                  // Price tag overlay on image
                  Positioned(
                    top: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: hennaDeep.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(color: hennaGold, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 5,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        '₹${design['price'] ?? '0'}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Details Section - Middle
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: hennaLight,
                borderRadius: const BorderRadius.vertical(
                  bottom: Radius.circular(25),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Design Type
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: hennaGold.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          design['design_type'] ?? 'Unnamed Design',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: hennaDeep,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Details Grid
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem(
                          icon: Icons.back_hand,
                          label: 'Hand Size',
                          value: design['hand_size'] ?? 'N/A',
                        ),
                      ),
                      Expanded(
                        child: _buildDetailItem(
                          icon: Icons.grid_view,
                          label: 'Coverage',
                          value: design['coverage'] ?? 'N/A',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Action Buttons - Bottom
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      // Edit Button
                      Container(
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [hennaBrown, hennaRose],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: [
                            BoxShadow(
                              color: hennaBrown.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: ElevatedButton.icon(
                          onPressed: () => _openEditDialog(design),
                          icon: const Icon(Icons.edit, color: Colors.white, size: 18),
                          label: const Text(
                            'Edit',
                            style: TextStyle(color: Colors.white, fontSize: 14),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                        ),
                      ),

                      // Delete Button
                      Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Colors.red, Colors.redAccent],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.red.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: ElevatedButton.icon(
                          onPressed: () => _deleteDesign(design['id'].toString()),
                          icon: const Icon(Icons.delete, color: Colors.white, size: 18),
                          label: const Text(
                            'Delete',
                            style: TextStyle(color: Colors.white, fontSize: 14),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.white,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build detail items
  Widget _buildDetailItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: hennaCream,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: hennaGold.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16, color: hennaBrown),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: hennaBrown.withOpacity(0.7),
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: hennaDeep,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Helper class to manage multiple controllers
class TextEditingCollection {
  final formKey = GlobalKey<FormState>();
  final designType = TextEditingController();
  final handSize = TextEditingController();
  final coverage = TextEditingController();
  final price = TextEditingController();

  void dispose() {
    designType.dispose();
    handSize.dispose();
    coverage.dispose();
    price.dispose();
  }
}